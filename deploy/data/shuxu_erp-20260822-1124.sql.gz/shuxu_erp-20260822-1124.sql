-- MySQL dump 10.19  Distrib 10.3.28-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: shuxu_erp
-- ------------------------------------------------------
-- Server version	10.3.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `audit_logs`
--

DROP TABLE IF EXISTS `audit_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `audit_logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) NOT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `action` varchar(50) NOT NULL,
  `method` varchar(10) NOT NULL,
  `path` varchar(255) NOT NULL,
  `target_type` varchar(30) DEFAULT NULL,
  `target_id` varchar(64) DEFAULT NULL,
  `status_code` int(11) DEFAULT NULL,
  `detail` text DEFAULT NULL,
  `ip` varchar(45) DEFAULT NULL,
  `ua` varchar(200) DEFAULT NULL,
  `duration_ms` int(11) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_al_tenant_time` (`tenant_id`,`created_at`),
  KEY `idx_al_target` (`target_type`,`target_id`),
  KEY `idx_al_user_time` (`user_id`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audit_logs`
--

LOCK TABLES `audit_logs` WRITE;
/*!40000 ALTER TABLE `audit_logs` DISABLE KEYS */;
INSERT INTO `audit_logs` VALUES (1,42,47,'verify_test1','auth.login','POST','/api/v1/auth/login','auth','47',200,NULL,'124.174.33.195','curl/8.5.0',0,'2026-08-22 16:04:25'),(2,43,48,'testerp','auth.register','POST','/api/v1/auth/register','tenant','43',200,NULL,'127.0.0.1','curl/7.61.1',0,'2026-08-22 16:06:28'),(3,43,48,'testerp','auth.login','POST','/api/v1/auth/login','auth','48',200,NULL,'127.0.0.1','curl/7.61.1',0,'2026-08-22 16:06:34'),(4,43,48,'testerp','auth.login','POST','/api/v1/auth/login','auth','48',200,NULL,'127.0.0.1','curl/7.61.1',0,'2026-08-22 16:17:49'),(5,43,48,'testerp','auth.login','POST','/api/v1/auth/login','auth','48',200,NULL,'127.0.0.1','curl/7.61.1',0,'2026-08-22 16:18:16'),(6,43,48,'testerp','shop.sync.post','POST','/api/v1/shops/:id/sync','sync','33',400,'{\"type\":\"orders\"}','127.0.0.1','curl/7.61.1',6,'2026-08-22 16:18:17'),(7,43,48,'testerp','shop.refreshToken.post','POST','/api/v1/shops/:id/refresh-token','refresh-token','33',400,'{}','127.0.0.1','curl/7.61.1',22,'2026-08-22 16:18:17'),(8,43,48,'testerp','auth.login','POST','/api/v1/auth/login','auth','48',200,NULL,'127.0.0.1','curl/7.61.1',0,'2026-08-22 16:18:44'),(9,43,48,'testerp','shop.sync.post','POST','/api/v1/shops/:id/sync','sync','34',400,'{\"type\":\"orders\"}','127.0.0.1','curl/7.61.1',3,'2026-08-22 16:18:44'),(10,43,48,'testerp','shop.sync.post','POST','/api/v1/shops/:id/sync','sync','34',400,'{\"type\":\"products\"}','127.0.0.1','curl/7.61.1',3,'2026-08-22 16:18:44'),(11,43,48,'testerp','shop.refreshToken.post','POST','/api/v1/shops/:id/refresh-token','refresh-token','34',400,'{}','127.0.0.1','curl/7.61.1',2,'2026-08-22 16:18:44'),(12,43,48,'testerp','notification.post','POST','/api/v1/notifications/','notifications',NULL,200,'{\"title\":\"P2冒烟测试通知\",\"body\":\"多平台适配器已部署\",\"level\":\"info\",\"audience\":\"tenant\"}','127.0.0.1','curl/7.61.1',6,'2026-08-22 16:18:44'),(13,43,48,'testerp','notification.delete','DELETE','/api/v1/notifications/:id',':id','2',200,NULL,'127.0.0.1','curl/7.61.1',5,'2026-08-22 16:18:44'),(14,43,48,'testerp','auth.login','POST','/api/v1/auth/login','auth','48',200,NULL,'127.0.0.1','curl/7.61.1',0,'2026-08-22 16:26:24'),(15,43,48,'testerp','auth.login','POST','/api/v1/auth/login','auth','48',200,NULL,'101.126.17.35','curl/8.5.0',0,'2026-08-22 16:52:47'),(16,43,48,'testerp','auth.login','POST','/api/v1/auth/login','auth','48',200,NULL,'115.190.92.241','curl/8.5.0',0,'2026-08-22 16:52:47'),(17,10,10,'demo','auth.login_failed','POST','/api/v1/auth/login','auth',NULL,401,'用户名或密码错误','115.191.63.211','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36',0,'2026-08-22 17:43:48'),(18,44,49,'browser_test_1787391954','auth.register','POST','/api/v1/auth/register','tenant','44',200,NULL,'115.191.57.248','curl/8.5.0',0,'2026-08-22 17:45:54'),(19,44,49,'browser_test_1787391954','auth.login','POST','/api/v1/auth/login','auth','49',200,NULL,'115.191.63.211','Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36',0,'2026-08-22 17:46:02'),(20,44,49,'browser_test_1787391954','auth.login','POST','/api/v1/auth/login','auth','49',200,NULL,'115.191.57.248','curl/8.5.0',0,'2026-08-22 18:02:59'),(21,44,49,'browser_test_1787391954','auth.login','POST','/api/v1/auth/login','auth','49',200,NULL,'124.174.33.195','curl/8.5.0',0,'2026-08-22 18:03:09'),(22,44,49,'browser_test_1787391954','auth.login','POST','/api/v1/auth/login','auth','49',200,NULL,'101.126.17.35','curl/8.5.0',0,'2026-08-22 18:03:20'),(23,44,49,'browser_test_1787391954','auth.login','POST','/api/v1/auth/login','auth','49',200,NULL,'124.174.33.195','curl/8.5.0',0,'2026-08-22 18:07:04'),(24,44,49,'browser_test_1787391954','auth.login','POST','/api/v1/auth/login','auth','49',200,NULL,'101.126.17.35','curl/8.5.0',0,'2026-08-22 18:09:31'),(25,9,9,'admin','auth.login','POST','/api/v1/auth/login','auth','9',200,NULL,'124.160.201.101','Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36 Edg/151.0.0.0',0,'2026-08-22 18:10:17');
/*!40000 ALTER TABLE `audit_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `carriers`
--

DROP TABLE IF EXISTS `carriers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `carriers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(30) DEFAULT NULL,
  `tracking_url` varchar(255) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_carriers_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `carriers`
--

LOCK TABLES `carriers` WRITE;
/*!40000 ALTER TABLE `carriers` DISABLE KEYS */;
INSERT INTO `carriers` VALUES (4,10,'云途物流 YunTu Express','YUNTU','https://t.17track.net/zh-cn#nums=','active','2026-08-22 10:38:57'),(5,10,'顺丰国际 SF International','SFINT','https://www.sf-international.com/track/','active','2026-08-22 10:38:57'),(6,10,'燕文物流 YanWen','YW','https://track.yw56.com.cn/','active','2026-08-22 10:38:57'),(11,21,'顺丰国际','SFINT',NULL,'active','2026-08-22 11:29:15'),(12,23,'云途物流','YUNTU','https://t.17track.net/zh-cn#nums=','active','2026-08-22 11:29:18'),(13,28,'云途物流','YUNTU','https://t.17track.net/zh-cn#nums=','active','2026-08-22 13:27:38'),(14,30,'云途物流','YUNTU','https://t.17track.net/zh-cn#nums=','active','2026-08-22 13:42:21'),(15,31,'云途物流','YUNTU','https://t.17track.net/zh-cn#nums=','active','2026-08-22 13:43:20'),(16,32,'云途物流','YUNTU','https://t.17track.net/zh-cn#nums=','active','2026-08-22 13:43:29'),(17,33,'云途物流','YUNTU','https://t.17track.net/zh-cn#nums=','active','2026-08-22 13:43:51'),(18,34,'云途物流','YUNTU','https://t.17track.net/zh-cn#nums=','active','2026-08-22 13:43:53'),(19,36,'云途物流','YUNTU','https://t.17track.net/zh-cn#nums=','active','2026-08-22 13:44:03'),(20,38,'云途物流','YUNTU','https://t.17track.net/zh-cn#nums=','active','2026-08-22 13:44:23'),(21,41,'云途物流','YUNTU','https://t.17track.net/zh-cn#nums=','active','2026-08-22 13:53:02');
/*!40000 ALTER TABLE `carriers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `exchange_rates`
--

DROP TABLE IF EXISTS `exchange_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `exchange_rates` (
  `code` varchar(8) NOT NULL,
  `rate` decimal(12,6) NOT NULL DEFAULT 1.000000,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exchange_rates`
--

LOCK TABLES `exchange_rates` WRITE;
/*!40000 ALTER TABLE `exchange_rates` DISABLE KEYS */;
INSERT INTO `exchange_rates` VALUES ('AED',1.970000,'2026-08-22 13:40:41'),('AUD',4.720000,'2026-08-22 13:40:41'),('BRL',1.320000,'2026-08-22 13:40:41'),('CAD',5.280000,'2026-08-22 13:40:41'),('CHF',8.200000,'2026-08-22 13:40:41'),('CNY',1.000000,'2026-08-22 13:40:41'),('DKK',1.050000,'2026-08-22 13:40:41'),('EUR',7.860000,'2026-08-22 13:40:41'),('GBP',9.180000,'2026-08-22 13:40:41'),('HKD',0.930000,'2026-08-22 13:40:41'),('IDR',0.000440,'2026-08-22 13:40:41'),('ILS',1.960000,'2026-08-22 13:40:41'),('INR',0.086000,'2026-08-22 13:40:41'),('JPY',0.048500,'2026-08-22 13:40:41'),('KRW',0.005200,'2026-08-22 13:40:41'),('MOP',0.900000,'2026-08-22 13:40:41'),('MXN',0.372000,'2026-08-22 13:40:41'),('MYR',1.550000,'2026-08-22 13:40:41'),('NGN',0.004400,'2026-08-22 13:40:41'),('NOK',0.670000,'2026-08-22 13:40:41'),('NZD',4.350000,'2026-08-22 13:40:41'),('PHP',0.127000,'2026-08-22 13:40:41'),('PLN',1.930000,'2026-08-22 13:40:41'),('RUB',0.080500,'2026-08-22 13:40:41'),('SAR',1.930000,'2026-08-22 13:40:41'),('SEK',0.680000,'2026-08-22 13:40:41'),('SGD',5.420000,'2026-08-22 13:40:41'),('THB',0.205000,'2026-08-22 13:40:41'),('TRY',0.210000,'2026-08-22 13:40:41'),('TWD',0.226000,'2026-08-22 13:40:41'),('USD',7.100000,'2026-08-22 13:53:00'),('VND',0.000280,'2026-08-22 13:40:41'),('ZAR',0.390000,'2026-08-22 13:40:41');
/*!40000 ALTER TABLE `exchange_rates` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `warehouse` varchar(50) NOT NULL DEFAULT 'MAIN',
  `qty_on_hand` int(11) NOT NULL DEFAULT 0,
  `qty_reserved` int(11) NOT NULL DEFAULT 0,
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_inventory` (`tenant_id`,`product_id`,`warehouse`),
  KEY `idx_inv_tenant_product` (`tenant_id`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory`
--

LOCK TABLES `inventory` WRITE;
/*!40000 ALTER TABLE `inventory` DISABLE KEYS */;
INSERT INTO `inventory` VALUES (5,10,5,'MAIN',197,0,'2026-08-22 10:42:04'),(6,10,6,'MAIN',297,2,'2026-08-22 10:42:05'),(7,10,7,'MAIN',396,2,'2026-08-22 10:42:06'),(8,10,8,'MAIN',595,0,'2026-08-22 10:42:06'),(9,10,9,'MAIN',490,3,'2026-08-22 10:42:06'),(10,10,10,'MAIN',250,1,'2026-08-22 10:42:05'),(15,21,15,'MAIN',98,0,'2026-08-22 11:29:16'),(16,23,16,'MAIN',98,0,'2026-08-22 11:29:20'),(17,28,17,'MAIN',98,0,'2026-08-22 13:27:39'),(18,30,18,'MAIN',98,0,'2026-08-22 13:42:21'),(19,31,19,'MAIN',98,0,'2026-08-22 13:43:20'),(20,32,20,'MAIN',98,0,'2026-08-22 13:43:29'),(21,33,21,'MAIN',98,0,'2026-08-22 13:43:51'),(22,34,22,'MAIN',98,0,'2026-08-22 13:43:54'),(23,36,23,'MAIN',98,0,'2026-08-22 13:44:04'),(24,38,24,'MAIN',98,0,'2026-08-22 13:44:24'),(25,41,25,'MAIN',98,0,'2026-08-22 13:53:03'),(26,44,26,'MAIN',5,0,'2026-08-22 18:09:34');
/*!40000 ALTER TABLE `inventory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `inventory_transactions`
--

DROP TABLE IF EXISTS `inventory_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `inventory_transactions` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `warehouse` varchar(50) NOT NULL DEFAULT 'MAIN',
  `change_type` varchar(20) NOT NULL,
  `qty_change` int(11) NOT NULL,
  `qty_before` int(11) NOT NULL DEFAULT 0,
  `qty_after` int(11) NOT NULL DEFAULT 0,
  `balance_field` varchar(20) NOT NULL DEFAULT 'on_hand',
  `ref_type` varchar(20) DEFAULT NULL,
  `ref_id` bigint(20) DEFAULT NULL,
  `operator` varchar(50) DEFAULT NULL,
  `remark` varchar(200) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_it_tenant_product_time` (`tenant_id`,`product_id`,`created_at`),
  KEY `idx_it_tenant_type_time` (`tenant_id`,`change_type`,`created_at`),
  KEY `idx_it_ref` (`ref_type`,`ref_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `inventory_transactions`
--

LOCK TABLES `inventory_transactions` WRITE;
/*!40000 ALTER TABLE `inventory_transactions` DISABLE KEYS */;
INSERT INTO `inventory_transactions` VALUES (1,44,26,'MAIN','inbound',5,0,5,'on_hand','manual',NULL,'browser_test_1787391954','修复体检: 测试入库5','2026-08-22 18:09:34');
/*!40000 ALTER TABLE `inventory_transactions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `login_attempts`
--

DROP TABLE IF EXISTS `login_attempts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `login_attempts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL,
  `ip` varchar(45) NOT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_la_user_time` (`username`,`created_at`),
  KEY `idx_la_ip_time` (`ip`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_attempts`
--

LOCK TABLES `login_attempts` WRITE;
/*!40000 ALTER TABLE `login_attempts` DISABLE KEYS */;
INSERT INTO `login_attempts` VALUES (6,'test','127.0.0.1',0,'2026-08-22 16:06:22'),(7,'demo','115.191.63.211',0,'2026-08-22 17:43:48'),(8,'browser_test_1787391941','115.190.92.241',0,'2026-08-22 17:45:41');
/*!40000 ALTER TABLE `login_attempts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notification_reads`
--

DROP TABLE IF EXISTS `notification_reads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_reads` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `notification_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `tenant_id` bigint(20) NOT NULL,
  `read_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_nr_notif_user` (`notification_id`,`user_id`),
  KEY `idx_nr_user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notification_reads`
--

LOCK TABLES `notification_reads` WRITE;
/*!40000 ALTER TABLE `notification_reads` DISABLE KEYS */;
INSERT INTO `notification_reads` VALUES (1,1,48,43,'2026-08-22 16:06:34'),(2,2,48,43,'2026-08-22 16:18:44');
/*!40000 ALTER TABLE `notification_reads` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `notifications`
--

DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) DEFAULT NULL,
  `category` varchar(30) NOT NULL DEFAULT 'system',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `title` varchar(200) NOT NULL,
  `body` text DEFAULT NULL,
  `link` varchar(500) DEFAULT NULL,
  `audience` varchar(20) NOT NULL DEFAULT 'tenant',
  `status` varchar(20) NOT NULL DEFAULT 'published',
  `created_by` varchar(50) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `expires_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_nt_tenant_status` (`tenant_id`,`status`,`created_at`),
  KEY `idx_nt_audience_status` (`audience`,`status`,`created_at`)
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notifications`
--

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
INSERT INTO `notifications` VALUES (1,42,'system','info','系统升级完成通知','已上线库存流水与审计日志功能',NULL,'tenant','published','verify_test1','2026-08-22 16:02:34',NULL),(6,25,'sync','warn','Temu 订单同步失败','店铺#15（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 16:25:56',NULL),(7,25,'sync','warn','Wildberries 订单同步失败','店铺#16（Wildberries）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 16:25:57',NULL),(8,26,'sync','warn','Temu 订单同步失败','店铺#17（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 16:25:57',NULL),(9,27,'sync','warn','Temu 订单同步失败','店铺#19（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 16:25:57',NULL),(10,40,'sync','warn','Temu 订单同步失败','店铺#30（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 16:25:57',NULL),(11,25,'sync','warn','Temu 订单同步失败','店铺#15（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 16:27:16',NULL),(12,25,'sync','warn','Wildberries 订单同步失败','店铺#16（Wildberries）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 16:27:16',NULL),(13,26,'sync','warn','Temu 订单同步失败','店铺#17（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 16:27:16',NULL),(14,27,'sync','warn','Temu 订单同步失败','店铺#19（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 16:27:16',NULL),(15,40,'sync','warn','Temu 订单同步失败','店铺#30（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 16:27:16',NULL),(16,25,'sync','warn','Temu 订单同步失败','店铺#15（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 16:56:16',NULL),(17,25,'sync','warn','Wildberries 订单同步失败','店铺#16（Wildberries）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 16:56:16',NULL),(18,26,'sync','warn','Temu 订单同步失败','店铺#17（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 16:56:16',NULL),(19,27,'sync','warn','Temu 订单同步失败','店铺#19（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 16:56:16',NULL),(20,40,'sync','warn','Temu 订单同步失败','店铺#30（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 16:56:16',NULL),(21,25,'sync','warn','Temu 订单同步失败','店铺#15（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 17:26:16',NULL),(22,25,'sync','warn','Wildberries 订单同步失败','店铺#16（Wildberries）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 17:26:16',NULL),(23,26,'sync','warn','Temu 订单同步失败','店铺#17（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 17:26:16',NULL),(24,27,'sync','warn','Temu 订单同步失败','店铺#19（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 17:26:16',NULL),(25,40,'sync','warn','Temu 订单同步失败','店铺#30（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 17:26:16',NULL),(26,25,'sync','warn','Temu 订单同步失败','店铺#15（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 17:56:16',NULL),(27,25,'sync','warn','Wildberries 订单同步失败','店铺#16（Wildberries）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 17:56:16',NULL),(28,26,'sync','warn','Temu 订单同步失败','店铺#17（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 17:56:16',NULL),(29,27,'sync','warn','Temu 订单同步失败','店铺#19（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 17:56:16',NULL),(30,40,'sync','warn','Temu 订单同步失败','店铺#30（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 17:56:16',NULL),(31,25,'sync','warn','Temu 订单同步失败','店铺#15（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 18:07:50',NULL),(32,25,'sync','warn','Wildberries 订单同步失败','店铺#16（Wildberries）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 18:07:50',NULL),(33,26,'sync','warn','Temu 订单同步失败','店铺#17（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 18:07:50',NULL),(34,27,'sync','warn','Temu 订单同步失败','店铺#19（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 18:07:50',NULL),(35,40,'sync','warn','Temu 订单同步失败','店铺#30（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 18:07:50',NULL),(36,25,'sync','warn','Temu 订单同步失败','店铺#15（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 18:10:10',NULL),(37,25,'sync','warn','Wildberries 订单同步失败','店铺#16（Wildberries）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 18:10:10',NULL),(38,26,'sync','warn','Temu 订单同步失败','店铺#17（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 18:10:10',NULL),(39,27,'sync','warn','Temu 订单同步失败','店铺#19（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 18:10:10',NULL),(40,40,'sync','warn','Temu 订单同步失败','店铺#30（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 18:10:10',NULL),(41,25,'sync','warn','Temu 订单同步失败','店铺#15（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 18:39:10',NULL),(42,25,'sync','warn','Wildberries 订单同步失败','店铺#16（Wildberries）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 18:39:10',NULL),(43,26,'sync','warn','Temu 订单同步失败','店铺#17（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 18:39:10',NULL),(44,27,'sync','warn','Temu 订单同步失败','店铺#19（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 18:39:10',NULL),(45,40,'sync','warn','Temu 订单同步失败','店铺#30（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 18:39:10',NULL),(46,25,'sync','warn','Temu 订单同步失败','店铺#15（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 19:09:10',NULL),(47,25,'sync','warn','Wildberries 订单同步失败','店铺#16（Wildberries）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 19:09:10',NULL),(48,26,'sync','warn','Temu 订单同步失败','店铺#17（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 19:09:10',NULL),(49,27,'sync','warn','Temu 订单同步失败','店铺#19（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 19:09:10',NULL),(50,40,'sync','warn','Temu 订单同步失败','店铺#30（Temu）自动同步失败：fetch failed。请检查授权状态或在店铺页手动同步。','/app/shops','tenant','published','scheduler','2026-08-22 19:09:10',NULL);
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `oauth_states`
--

DROP TABLE IF EXISTS `oauth_states`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `oauth_states` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `state` varchar(64) NOT NULL,
  `platform` varchar(30) NOT NULL,
  `tenant_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `code_verifier` varchar(128) DEFAULT NULL COMMENT 'PKCE verifier(Etsy)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `state` (`state`),
  KEY `idx_oauth_states_exp` (`expires_at`)
) ENGINE=InnoDB AUTO_INCREMENT=106 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `oauth_states`
--

LOCK TABLES `oauth_states` WRITE;
/*!40000 ALTER TABLE `oauth_states` DISABLE KEYS */;
INSERT INTO `oauth_states` VALUES (104,'f27203f0b09eff68f2b79bce65e7474ad86ae108fc7c87b6','TikTok Shop',9,9,'2026-08-22 18:20:40','2026-08-22 18:10:40',NULL),(105,'06022befa3ac85055084c402b4110d63ea426142605301ba','TikTok Shop',9,9,'2026-08-22 18:20:42','2026-08-22 18:10:42',NULL);
/*!40000 ALTER TABLE `oauth_states` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_items`
--

DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `order_items` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `qty` int(11) NOT NULL,
  `unit_price` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_order_items_order` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_items`
--

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
INSERT INTO `order_items` VALUES (9,10,9,5,2,29.90),(10,10,10,6,3,19.90),(11,10,11,8,5,12.90),(12,10,12,5,1,29.90),(13,10,13,9,10,9.90),(14,10,14,7,4,15.90),(15,10,15,10,1,24.90),(16,10,16,6,2,19.90),(17,10,17,9,3,9.90),(18,10,18,7,2,15.90),(19,10,19,8,1,12.90),(28,21,28,15,2,29.90),(29,21,29,15,5,29.90),(30,23,30,16,2,29.90),(31,23,31,16,1,29.90),(32,28,32,17,2,29.90),(33,28,33,17,1,29.90),(34,30,34,18,2,29.90),(35,31,35,19,2,29.90),(36,32,36,20,2,29.90),(37,33,37,21,2,29.90),(38,34,38,22,2,29.90),(39,34,39,22,1,29.90),(40,36,40,23,2,29.90),(41,36,41,23,1,29.90),(42,38,42,24,2,29.90),(43,38,43,24,1,29.90),(44,41,44,25,2,29.90);
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `orders` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) NOT NULL,
  `order_no` varchar(32) NOT NULL,
  `shop_id` bigint(20) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'PENDING',
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `buyer_name` varchar(100) DEFAULT NULL,
  `country` varchar(10) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `currency` varchar(8) NOT NULL DEFAULT 'CNY' COMMENT '订单币种',
  `exchange_rate` decimal(12,6) NOT NULL DEFAULT 1.000000 COMMENT '下单时汇率(币种→CNY)',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_orders_tenant_no` (`tenant_id`,`order_no`),
  KEY `idx_orders_tenant_status` (`tenant_id`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orders`
--

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
INSERT INTO `orders` VALUES (9,10,'SX202608229796DD',6,'COMPLETED',59.80,'Michael Johnson','US','2026-08-22 10:42:02','CNY',1.000000),(10,10,'SX2026082254398A',6,'COMPLETED',59.70,'Emily Davis','US','2026-08-22 10:42:03','CNY',1.000000),(11,10,'SX20260822FD125D',7,'COMPLETED',64.50,'Ahmad bin Ali','MY','2026-08-22 10:42:03','CNY',1.000000),(12,10,'SX2026082274BF70',6,'SHIPPED',29.90,'Sarah Wilson','US','2026-08-22 10:42:04','CNY',1.000000),(13,10,'SX202608228B2482',8,'SHIPPED',99.00,'Nguyen Thi Lan','VN','2026-08-22 10:42:04','CNY',1.000000),(14,10,'SX20260822641AC2',7,'SHIPPED',63.60,'Tan Wei Ming','SG','2026-08-22 10:42:05','CNY',1.000000),(15,10,'SX2026082247900A',6,'PAID',24.90,'David Brown','US','2026-08-22 10:42:05','CNY',1.000000),(16,10,'SX20260822D17653',7,'PAID',39.80,'Siti Nurhaliza','ID','2026-08-22 10:42:05','CNY',1.000000),(17,10,'SX2026082252375A',6,'PENDING',29.70,'James Miller','US','2026-08-22 10:42:06','CNY',1.000000),(18,10,'SX2026082296A418',8,'PENDING',31.80,'Maria Santos','PH','2026-08-22 10:42:06','CNY',1.000000),(19,10,'SX2026082241D620',6,'CANCELLED',12.90,'Robert Taylor','US','2026-08-22 10:42:06','CNY',1.000000),(28,21,'SX2026082271FCC9',13,'COMPLETED',59.80,'John Smith','US','2026-08-22 11:29:15','CNY',1.000000),(29,21,'SX20260822637673',13,'CANCELLED',149.50,'Cancel Test','US','2026-08-22 11:29:16','CNY',1.000000),(30,23,'SX2026082274726E',14,'SHIPPED',59.80,'John Smith','US','2026-08-22 11:29:19','CNY',1.000000),(31,23,'SX2026082263FD86',14,'CANCELLED',29.90,'NoCarrier','US','2026-08-22 11:29:20','CNY',1.000000),(32,28,'SX2026082271C5A5',21,'SHIPPED',59.80,'John Smith','US','2026-08-22 13:27:38','CNY',1.000000),(33,28,'SX20260822CCC5E3',21,'CANCELLED',29.90,'NoCarrier','US','2026-08-22 13:27:39','CNY',1.000000),(34,30,'SX20260822ED8722',23,'SHIPPED',59.80,'John Smith','US','2026-08-22 13:42:18','USD',7.240000),(35,31,'SX20260822A5FAB4',24,'SHIPPED',59.80,'John Smith','US','2026-08-22 13:43:17','USD',7.100000),(36,32,'SX202608220D7871',25,'SHIPPED',59.80,'John Smith','US','2026-08-22 13:43:26','USD',7.100000),(37,33,'SX202608226889AB',26,'SHIPPED',59.80,'John Smith','US','2026-08-22 13:43:48','USD',7.240000),(38,34,'SX202608228E7C19',27,'SHIPPED',59.80,'John Smith','US','2026-08-22 13:43:53','CNY',1.000000),(39,34,'SX20260822DDAD38',27,'CANCELLED',29.90,'NoCarrier','US','2026-08-22 13:43:54','CNY',1.000000),(40,36,'SX20260822F29431',28,'SHIPPED',59.80,'John Smith','US','2026-08-22 13:44:03','CNY',1.000000),(41,36,'SX202608224D199D',28,'CANCELLED',29.90,'NoCarrier','US','2026-08-22 13:44:04','CNY',1.000000),(42,38,'SX2026082228DCC3',29,'SHIPPED',59.80,'John Smith','US','2026-08-22 13:44:23','CNY',1.000000),(43,38,'SX20260822379662',29,'CANCELLED',29.90,'NoCarrier','US','2026-08-22 13:44:24','CNY',1.000000),(44,41,'SX2026082270FD2A',32,'SHIPPED',59.80,'John Smith','US','2026-08-22 13:53:00','USD',7.240000);
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `platform_apps`
--

DROP TABLE IF EXISTS `platform_apps`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `platform_apps` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `platform` varchar(30) NOT NULL,
  `app_id` varchar(120) NOT NULL,
  `client_id` varchar(120) DEFAULT NULL,
  `app_secret_enc` varchar(512) NOT NULL,
  `extra_json` text DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `platform` (`platform`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `platform_apps`
--

LOCK TABLES `platform_apps` WRITE;
/*!40000 ALTER TABLE `platform_apps` DISABLE KEYS */;
INSERT INTO `platform_apps` VALUES (13,'Amazon','amz-app',NULL,'F8WaNg/nUWX//3yTFtzpRrhabBUaTSXunJ9W48iKShE=',NULL,'active','2026-08-22 11:53:38','2026-08-22 11:53:38'),(14,'Shopee','2000001',NULL,'uRywbpePZRl7ncsMIfzVVea6+FavK2zZBb5/7aAMizE=',NULL,'active','2026-08-22 11:53:38','2026-08-22 11:53:38'),(15,'TikTok Shop','ttk-app',NULL,'9kD5b5+QpZqmb2n5dqFT+Xdw4TRTgD6BEt5GSKfqdwk=',NULL,'active','2026-08-22 11:53:38','2026-08-22 11:53:38'),(16,'Lazada','100234',NULL,'+XdLXeJQNVe5MBso6bgCzapF27UYloaO7dKJbtU9guE=',NULL,'active','2026-08-22 11:53:38','2026-08-22 11:53:38'),(17,'AliExpress','ae-app',NULL,'XSqWQWh72OkBFjRP//tWC4V7mH1KlOssb0BIgizVfck=',NULL,'active','2026-08-22 11:53:39','2026-08-22 11:53:39'),(18,'eBay','ebay-app',NULL,'ex6MYSFK0HyneEe4YSXPB3YMa2yPPVRwVpOvLTA/jjg=',NULL,'active','2026-08-22 11:53:39','2026-08-22 11:53:39'),(19,'Mercado Libre','ml-app',NULL,'HCjZlF3Nw7Bai2fFSEtMuLdB8kvYozD6jUKG5CZLBiI=',NULL,'active','2026-08-22 11:53:39','2026-08-22 11:53:39'),(20,'Wish','wish-app',NULL,'LjXx086k6+my8n19VXDMH7PQ+yD7z3bFXMVcKqUYH/k=',NULL,'active','2026-08-22 11:53:40','2026-08-22 11:53:40'),(21,'Etsy','etsy-app',NULL,'eZnVNObCEgIAVBGiv6havjWWsZ9h7C75LEfKtbxZs3E=',NULL,'active','2026-08-22 11:53:40','2026-08-22 11:53:40'),(22,'Allegro','al-app',NULL,'Tplwm8CYZlGqjBqGqqEGSd35bDvcNW7TGX6ZyJ5kHdRr',NULL,'active','2026-08-22 11:53:40','2026-08-22 11:53:40'),(23,'Douyin','dy-app',NULL,'8fhDF6Sj7wt8alLEZJPViE0I6L4epqLcDZzHcvAWcg+e',NULL,'active','2026-08-22 11:53:40','2026-08-22 11:53:40'),(24,'Shopify','sf-app',NULL,'VmtTSL6JNN+9dVRdGAX+GTUWCdUzSCBljYyJL2tpVAaN',NULL,'active','2026-08-22 11:53:41','2026-08-22 11:53:41'),(25,'Shoplazza','sz-app',NULL,'zdem/DFLbdossQtICeiCRORPzaUnViTlx+uwuoF/iMrf',NULL,'active','2026-08-22 11:53:41','2026-08-22 11:53:41'),(26,'Shopline','sl-app',NULL,'DJ459k0EvxUMqV2pBekIJ3l8qX/U30ywZm6ixg+d3uFK',NULL,'active','2026-08-22 11:53:41','2026-08-22 11:53:41'),(27,'Temu','temu-app',NULL,'T7M9N2ZNWqayjqy5gmxxh0zMWfrqt/BqOSqg9N7Bg8PR',NULL,'active','2026-08-22 11:53:42','2026-08-22 11:53:42'),(28,'SHEIN','shein-app',NULL,'Ji1bUB/yIAjHArIKC1Vtc/bNe+9+PvTR7Yk193IE1m3z',NULL,'active','2026-08-22 11:53:42','2026-08-22 11:53:42'),(29,'Coupang','cp-app',NULL,'40HJMmlHVq/k3Tscec3ldR/9VWeqdujtNqMMwigg28MN',NULL,'active','2026-08-22 11:53:42','2026-08-22 11:53:42'),(30,'OZON','ozon-app',NULL,'+ZfOIp2FdjxPlPMcPywpk6xBH38zSK2C8kRyMUjV4nYK',NULL,'active','2026-08-22 11:53:42','2026-08-22 11:53:42'),(31,'Wildberries','wb-app',NULL,'zZWuTNujsaxGvZWOSv6xFViQILXhHaj08Olg8n4u+t6m',NULL,'active','2026-08-22 11:53:43','2026-08-22 11:53:43'),(32,'Walmart','wm-app',NULL,'bcd8H4viiL29igU2x+RZ0Qqhq1B3jW+Vt8Z2zCnYCexv',NULL,'active','2026-08-22 11:53:43','2026-08-22 11:53:43'),(33,'Fruugo','fr-app',NULL,'w89pquDYgpkzk3GvbD9w2sD3OglcmKMoybXwNifuvG0V',NULL,'active','2026-08-22 11:53:43','2026-08-22 11:53:43'),(34,'Qoo10','q10-app',NULL,'mZPyWuRGDUe0nYCssg9NeV/ryg/nyNgi1bCPQT0n57SF',NULL,'active','2026-08-22 11:53:43','2026-08-22 11:53:43'),(35,'Kaufland','kl-app',NULL,'2aF8UqI5qBaIgx1lu15nYDYJfWHwyUJfMMeabP1yqPl3',NULL,'active','2026-08-22 11:53:44','2026-08-22 11:53:44'),(36,'OnBuy','ob-app',NULL,'dWanbRmV6Qh6DQS85gVC3P5lsgHjDcaytNl+4cg1ZkuS',NULL,'active','2026-08-22 11:53:44','2026-08-22 11:53:44');
/*!40000 ALTER TABLE `platform_apps` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) NOT NULL,
  `sku` varchar(64) NOT NULL,
  `name` varchar(200) NOT NULL,
  `category` varchar(50) DEFAULT NULL,
  `price` decimal(12,2) NOT NULL DEFAULT 0.00,
  `cost` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_products_tenant_sku` (`tenant_id`,`sku`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (5,10,'SX-WATCH-S8','Smart Watch S8 智能手表 美版','Electronics',29.90,12.50,'2026-08-22 10:38:55'),(6,10,'SX-EARBUDS-PRO','Wireless Earbuds Pro 无线耳机','Electronics',19.90,8.20,'2026-08-22 10:38:55'),(7,10,'SX-LAMP-LED','LED Desk Lamp 折叠台灯 USB','Home & Kitchen',15.90,5.80,'2026-08-22 10:38:56'),(8,10,'SX-CUP-VAC','Vacuum Insulated Cup 真空保温杯 500ml','Home & Kitchen',12.90,4.50,'2026-08-22 10:38:56'),(9,10,'SX-CABLE-3IN1','3-in-1 Fast Charging Cable 三合一数据线','Electronics',9.90,3.10,'2026-08-22 10:38:56'),(10,10,'SX-BAG-BACK','Anti-theft Backpack 防盗双肩包','Bags & Luggage',24.90,9.60,'2026-08-22 10:38:56'),(15,21,'E2E-SKU-001','无线蓝牙耳机 Pro','Electronics',29.90,12.50,'2026-08-22 11:29:14'),(16,23,'P3-SKU-001','智能手表 S8','Electronics',29.90,15.00,'2026-08-22 11:29:18'),(17,28,'P3-SKU-001','智能手表 S8','Electronics',29.90,15.00,'2026-08-22 13:27:37'),(18,30,'P6-USD-001','Smart Watch S8','Electronics',29.90,15.00,'2026-08-22 13:42:17'),(19,31,'P6-USD-001','Smart Watch S8','Electronics',29.90,15.00,'2026-08-22 13:43:17'),(20,32,'P6-USD-001','Smart Watch S8','Electronics',29.90,15.00,'2026-08-22 13:43:25'),(21,33,'P6-USD-001','Smart Watch S8','Electronics',29.90,15.00,'2026-08-22 13:43:48'),(22,34,'P3-SKU-001','智能手表 S8','Electronics',29.90,15.00,'2026-08-22 13:43:52'),(23,36,'P3-SKU-001','智能手表 S8','Electronics',29.90,15.00,'2026-08-22 13:44:02'),(24,38,'P3-SKU-001','智能手表 S8','Electronics',29.90,15.00,'2026-08-22 13:44:22'),(25,41,'P6-USD-001','Smart Watch S8','Electronics',29.90,15.00,'2026-08-22 13:52:59'),(26,44,'TEST-FIX-001','完善测试商品',NULL,99.00,30.00,'2026-08-22 18:09:31');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase_items`
--

DROP TABLE IF EXISTS `purchase_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_items` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) NOT NULL,
  `purchase_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `qty` int(11) NOT NULL,
  `unit_cost` decimal(12,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`),
  KEY `idx_purchase_items_purchase` (`purchase_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_items`
--

LOCK TABLES `purchase_items` WRITE;
/*!40000 ALTER TABLE `purchase_items` DISABLE KEYS */;
INSERT INTO `purchase_items` VALUES (3,10,3,10,10,12.50),(4,10,4,5,200,12.50),(5,10,4,6,300,8.20),(6,10,4,9,500,3.10),(7,10,5,7,400,5.80),(8,10,5,8,600,4.50),(9,10,5,10,250,9.60),(10,10,6,5,150,12.00),(14,23,10,16,100,15.00),(15,28,11,17,100,15.00),(16,30,12,18,100,15.00),(17,31,13,19,100,15.00),(18,32,14,20,100,15.00),(19,33,15,21,100,15.00),(20,34,16,22,100,15.00),(21,36,17,23,100,15.00),(22,38,18,24,100,15.00),(23,41,19,25,100,15.00);
/*!40000 ALTER TABLE `purchase_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchases`
--

DROP TABLE IF EXISTS `purchases`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchases` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) NOT NULL,
  `purchase_no` varchar(32) NOT NULL,
  `supplier_id` bigint(20) DEFAULT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'DRAFT',
  `total_amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `remark` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_purchases_tenant_no` (`tenant_id`,`purchase_no`),
  KEY `idx_purchases_tenant_status` (`tenant_id`,`status`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchases`
--

LOCK TABLES `purchases` WRITE;
/*!40000 ALTER TABLE `purchases` DISABLE KEYS */;
INSERT INTO `purchases` VALUES (3,10,'PO20260822A149',3,'DRAFT',125.00,NULL,'2026-08-22 10:40:52'),(4,10,'PO202608229A1C',3,'RECEIVED',6510.00,NULL,'2026-08-22 10:42:01'),(5,10,'PO20260822268C',4,'RECEIVED',7420.00,NULL,'2026-08-22 10:42:02'),(6,10,'PO202608220F62',3,'DRAFT',1800.00,NULL,'2026-08-22 10:42:02'),(10,23,'PO202608220477',9,'RECEIVED',1500.00,NULL,'2026-08-22 11:29:18'),(11,28,'PO202608227F68',10,'RECEIVED',1500.00,NULL,'2026-08-22 13:27:38'),(12,30,'PO202608225304',NULL,'RECEIVED',1500.00,NULL,'2026-08-22 13:42:17'),(13,31,'PO202608228809',NULL,'RECEIVED',1500.00,NULL,'2026-08-22 13:43:17'),(14,32,'PO2026082220C2',NULL,'RECEIVED',1500.00,NULL,'2026-08-22 13:43:25'),(15,33,'PO20260822FFFA',NULL,'RECEIVED',1500.00,NULL,'2026-08-22 13:43:48'),(16,34,'PO20260822E255',11,'RECEIVED',1500.00,NULL,'2026-08-22 13:43:52'),(17,36,'PO2026082296D0',12,'RECEIVED',1500.00,NULL,'2026-08-22 13:44:03'),(18,38,'PO2026082295AF',13,'RECEIVED',1500.00,NULL,'2026-08-22 13:44:22'),(19,41,'PO202608221251',NULL,'RECEIVED',1500.00,NULL,'2026-08-22 13:52:59');
/*!40000 ALTER TABLE `purchases` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipment_events`
--

DROP TABLE IF EXISTS `shipment_events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipment_events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) NOT NULL,
  `shipment_id` bigint(20) NOT NULL,
  `status` varchar(50) DEFAULT NULL COMMENT '轨迹节点状态',
  `description` varchar(255) DEFAULT NULL,
  `location` varchar(120) DEFAULT NULL,
  `occurred_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_shipment_events` (`tenant_id`,`shipment_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipment_events`
--

LOCK TABLES `shipment_events` WRITE;
/*!40000 ALTER TABLE `shipment_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `shipment_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shipments`
--

DROP TABLE IF EXISTS `shipments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shipments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) NOT NULL,
  `order_id` bigint(20) NOT NULL,
  `carrier_id` bigint(20) DEFAULT NULL,
  `tracking_no` varchar(64) DEFAULT NULL,
  `shipping_cost` decimal(12,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_shipments_order` (`tenant_id`,`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shipments`
--

LOCK TABLES `shipments` WRITE;
/*!40000 ALTER TABLE `shipments` DISABLE KEYS */;
INSERT INTO `shipments` VALUES (4,10,9,4,'YT2608200001US',8.50,'2026-08-22 10:42:03'),(5,10,10,5,'SF7730012345US',6.20,'2026-08-22 10:42:03'),(6,10,11,4,'YT2608210002MY',4.80,'2026-08-22 10:42:04'),(7,10,12,4,'YT2608220003US',8.50,'2026-08-22 10:42:04'),(8,10,13,4,'YT2608220004VN',3.20,'2026-08-22 10:42:05'),(9,10,14,5,'SF7730099999SG',5.60,'2026-08-22 10:42:05'),(14,21,28,11,'SF123456789',12.00,'2026-08-22 11:29:15'),(15,23,30,12,'YT2608220001CN',8.50,'2026-08-22 11:29:19'),(16,28,32,13,'YT2608220001CN',8.50,'2026-08-22 13:27:39'),(17,30,34,14,'YT1787377341CN',8.50,'2026-08-22 13:42:21'),(18,31,35,15,'YT1787377400CN',8.50,'2026-08-22 13:43:20'),(19,32,36,16,'YT1787377409CN',8.50,'2026-08-22 13:43:29'),(20,33,37,17,'YT1787377431CN',8.50,'2026-08-22 13:43:51'),(21,34,38,18,'YT2608220001CN',8.50,'2026-08-22 13:43:53'),(22,36,40,19,'YT2608220001CN',8.50,'2026-08-22 13:44:03'),(23,38,42,20,'YT2608220001CN',8.50,'2026-08-22 13:44:23'),(24,41,44,21,'YT1787377982CN',8.50,'2026-08-22 13:53:03');
/*!40000 ALTER TABLE `shipments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `shops`
--

DROP TABLE IF EXISTS `shops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shops` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `platform` varchar(30) NOT NULL,
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `commission_rate` decimal(5,4) NOT NULL DEFAULT 0.0000 COMMENT '平台佣金率(0-1)',
  `auth_status` varchar(20) NOT NULL DEFAULT 'manual' COMMENT 'manual未授权/authorized已授权/expired已过期',
  `ext_shop_id` varchar(120) DEFAULT NULL COMMENT '平台侧店铺ID',
  `ext_shop_name` varchar(200) DEFAULT NULL COMMENT '平台侧店铺名',
  `access_token_enc` varchar(1024) DEFAULT NULL COMMENT '访问令牌(加密)',
  `refresh_token_enc` varchar(1024) DEFAULT NULL COMMENT '刷新令牌(加密)',
  `token_expires_at` datetime DEFAULT NULL COMMENT '令牌到期时间',
  `authorized_at` datetime DEFAULT NULL COMMENT '最近授权时间',
  `last_sync_at` datetime DEFAULT NULL COMMENT '最近同步时间',
  `api_key_enc` varchar(1024) DEFAULT NULL COMMENT 'API密钥(加密,密钥型平台)',
  `api_secret_enc` varchar(1024) DEFAULT NULL COMMENT 'API第二密钥(加密)',
  `currency` varchar(8) NOT NULL DEFAULT 'CNY' COMMENT '店铺结算币种',
  PRIMARY KEY (`id`),
  KEY `idx_shops_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `shops`
--

LOCK TABLES `shops` WRITE;
/*!40000 ALTER TABLE `shops` DISABLE KEYS */;
INSERT INTO `shops` VALUES (7,10,'Shopee 马来站','Shopee','active','2026-08-22 10:38:55',0.0600,'manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CNY'),(8,10,'TikTok Shop 东南亚','TikTok Shop','active','2026-08-22 10:38:55',0.0500,'manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CNY'),(13,21,'US-测试旗舰店','Amazon','active','2026-08-22 11:29:14',0.0000,'manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CNY'),(14,23,'US-旗舰店','Amazon','active','2026-08-22 11:29:17',0.0850,'manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CNY'),(15,25,'Temu 主店','Temu','active','2026-08-22 12:00:20',0.0000,'authorized',NULL,NULL,NULL,NULL,NULL,'2026-08-22 12:00:20',NULL,'hjZnaLQ5jhU3/Rr0szPcXYZg0ZgCPMkChUMivKy15JdDMpH2GG5xIgyMEwuF0Q==','xJj6GOuRoGcZflF2mNnOW38Urf2gJY7rllGABa9vEh2UToUFndFovRWAzQ==','CNY'),(16,25,'WB 店','Wildberries','active','2026-08-22 12:00:20',0.0000,'authorized',NULL,NULL,NULL,NULL,NULL,'2026-08-22 12:00:20',NULL,'VbzpHSUq2u4c2r0gg92AYlm7vqoAUVvWpa/ZmLg4Y8iO0kq2Fmayyg==',NULL,'CNY'),(17,26,'Temu 主店','Temu','active','2026-08-22 12:00:53',0.0000,'authorized',NULL,NULL,NULL,NULL,NULL,'2026-08-22 12:00:53',NULL,'TGy/CqUwc7EKArUxaDp3gcpzztktffF9n4Yf1ZJ2ws5BJkTrCjoZiwRolrtcDg==','e5vBFpcmfg2NeCtaGzQG6Y2W9xDUM9zvT9qzk+7FtFX6bkDTANKDpaQMGQ==','CNY'),(18,26,'WB 店','Wildberries','active','2026-08-22 12:00:53',0.0000,'manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CNY'),(19,27,'Temu 主店','Temu','active','2026-08-22 13:22:11',0.0000,'authorized',NULL,NULL,NULL,NULL,NULL,'2026-08-22 13:22:11',NULL,'8pmeSVDWnjZ68dHqBHDGPobzhzyKQ/DA7Y0ruW63R5NUg05RTw3CQumhIx3/VA==','ZTO5zUOZ4R9pSGwYdH4v418Iv/3AS43WbM/hbfj7NXsW628WyoLGokWpfg==','CNY'),(20,27,'WB 店','Wildberries','active','2026-08-22 13:22:11',0.0000,'manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CNY'),(21,28,'US-旗舰店','Amazon','active','2026-08-22 13:27:37',0.0850,'manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CNY'),(23,30,'US- Dollar 店','Amazon','active','2026-08-22 13:42:17',0.0850,'manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'USD'),(24,31,'US- Dollar 店','Amazon','active','2026-08-22 13:43:17',0.0850,'manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'USD'),(25,32,'US- Dollar 店','Amazon','active','2026-08-22 13:43:25',0.0850,'manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'USD'),(26,33,'US- Dollar 店','Amazon','active','2026-08-22 13:43:48',0.0850,'manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'USD'),(27,34,'US-旗舰店','Amazon','active','2026-08-22 13:43:52',0.0850,'manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CNY'),(28,36,'US-旗舰店','Amazon','active','2026-08-22 13:44:02',0.0850,'manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CNY'),(29,38,'US-旗舰店','Amazon','active','2026-08-22 13:44:22',0.0850,'manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CNY'),(30,40,'Temu 主店','Temu','active','2026-08-22 13:44:27',0.0000,'authorized',NULL,NULL,NULL,NULL,NULL,'2026-08-22 13:44:27',NULL,'wEdSJW1y/KIf4CX2EQ0ON+BEtNSsfZvt6ClkhdoWMdfc3DhNuXo7pk7A9LJINw==','JpqDt4FiT2Z9ZzizFVs4NZ8x9qun4s2L66msf+M8uiKgA8PwVjn1JSe9JQ==','USD'),(31,40,'WB 店','Wildberries','active','2026-08-22 13:44:27',0.0000,'manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'RUB'),(32,41,'US- Dollar 店','Amazon','active','2026-08-22 13:52:59',0.0850,'manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'USD'),(35,44,'测试店铺-WB','Wildberries','active','2026-08-22 18:09:31',0.0500,'manual',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'CNY');
/*!40000 ALTER TABLE `shops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `suppliers` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) NOT NULL,
  `name` varchar(100) NOT NULL,
  `contact` varchar(50) DEFAULT NULL,
  `phone` varchar(30) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_suppliers_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
INSERT INTO `suppliers` VALUES (3,10,'深圳市华强北电子供应链','王经理','13800138000',NULL,'2026-08-22 10:38:55'),(4,10,'宁波家居用品制造厂','李厂长','13905740001',NULL,'2026-08-22 10:38:55'),(9,23,'深圳华强北供应链','王经理','13800138000',NULL,'2026-08-22 11:29:18'),(10,28,'深圳华强北供应链','王经理','13800138000',NULL,'2026-08-22 13:27:38'),(11,34,'深圳华强北供应链','王经理','13800138000',NULL,'2026-08-22 13:43:52'),(12,36,'深圳华强北供应链','王经理','13800138000',NULL,'2026-08-22 13:44:02'),(13,38,'深圳华强北供应链','王经理','13800138000',NULL,'2026-08-22 13:44:22');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sync_jobs`
--

DROP TABLE IF EXISTS `sync_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sync_jobs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) NOT NULL,
  `shop_id` bigint(20) NOT NULL,
  `platform` varchar(30) NOT NULL,
  `job_type` varchar(20) NOT NULL DEFAULT 'orders',
  `status` varchar(20) NOT NULL DEFAULT 'pending',
  `imported` int(11) NOT NULL DEFAULT 0,
  `skipped` int(11) NOT NULL DEFAULT 0,
  `message` text DEFAULT NULL,
  `started_at` datetime DEFAULT NULL,
  `finished_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sj_tenant_shop` (`tenant_id`,`shop_id`,`created_at`),
  KEY `idx_sj_status` (`status`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sync_jobs`
--

LOCK TABLES `sync_jobs` WRITE;
/*!40000 ALTER TABLE `sync_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `sync_jobs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sync_logs`
--

DROP TABLE IF EXISTS `sync_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sync_logs` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) NOT NULL,
  `shop_id` bigint(20) NOT NULL,
  `platform` varchar(30) DEFAULT NULL COMMENT '平台名',
  `job_type` varchar(20) NOT NULL DEFAULT 'orders' COMMENT '任务类型 orders/products',
  `imported` int(11) NOT NULL DEFAULT 0 COMMENT '本轮导入数',
  `skipped` int(11) NOT NULL DEFAULT 0 COMMENT '本轮跳过数',
  `status` varchar(20) NOT NULL,
  `message` varchar(500) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `finished_at` datetime DEFAULT NULL COMMENT '完成时间',
  PRIMARY KEY (`id`),
  KEY `idx_sync_logs_shop` (`tenant_id`,`shop_id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sync_logs`
--

LOCK TABLES `sync_logs` WRITE;
/*!40000 ALTER TABLE `sync_logs` DISABLE KEYS */;
INSERT INTO `sync_logs` VALUES (1,25,15,NULL,'auth',0,0,'ok','API 密钥已录入（加密存储）','2026-08-22 12:00:20',NULL),(2,25,16,NULL,'auth',0,0,'ok','API 密钥已录入（加密存储）','2026-08-22 12:00:20',NULL),(3,26,17,NULL,'auth',0,0,'ok','API 密钥已录入（加密存储）','2026-08-22 12:00:53',NULL),(4,26,18,NULL,'auth',0,0,'ok','API 密钥已录入（加密存储）','2026-08-22 12:00:53',NULL),(5,27,19,NULL,'auth',0,0,'ok','API 密钥已录入（加密存储）','2026-08-22 13:22:11',NULL),(6,27,20,NULL,'auth',0,0,'ok','API 密钥已录入（加密存储）','2026-08-22 13:22:11',NULL),(7,40,30,NULL,'auth',0,0,'ok','API 密钥已录入（加密存储）','2026-08-22 13:44:27',NULL),(8,40,31,NULL,'auth',0,0,'ok','API 密钥已录入（加密存储）','2026-08-22 13:44:27',NULL),(11,25,15,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 16:25:56','2026-08-22 16:25:56'),(12,25,16,'Wildberries','orders',0,0,'failed','fetch failed','2026-08-22 16:25:57','2026-08-22 16:25:57'),(13,26,17,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 16:25:57','2026-08-22 16:25:57'),(14,27,19,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 16:25:57','2026-08-22 16:25:57'),(15,40,30,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 16:25:57','2026-08-22 16:25:57'),(16,25,15,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 16:27:16','2026-08-22 16:27:16'),(17,25,16,'Wildberries','orders',0,0,'failed','fetch failed','2026-08-22 16:27:16','2026-08-22 16:27:16'),(18,26,17,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 16:27:16','2026-08-22 16:27:16'),(19,27,19,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 16:27:16','2026-08-22 16:27:16'),(20,40,30,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 16:27:16','2026-08-22 16:27:16'),(21,25,15,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 16:56:16','2026-08-22 16:56:16'),(22,25,16,'Wildberries','orders',0,0,'failed','fetch failed','2026-08-22 16:56:16','2026-08-22 16:56:16'),(23,26,17,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 16:56:16','2026-08-22 16:56:16'),(24,27,19,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 16:56:16','2026-08-22 16:56:16'),(25,40,30,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 16:56:16','2026-08-22 16:56:16'),(26,25,15,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 17:26:16','2026-08-22 17:26:16'),(27,25,16,'Wildberries','orders',0,0,'failed','fetch failed','2026-08-22 17:26:16','2026-08-22 17:26:16'),(28,26,17,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 17:26:16','2026-08-22 17:26:16'),(29,27,19,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 17:26:16','2026-08-22 17:26:16'),(30,40,30,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 17:26:16','2026-08-22 17:26:16'),(31,25,15,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 17:56:16','2026-08-22 17:56:16'),(32,25,16,'Wildberries','orders',0,0,'failed','fetch failed','2026-08-22 17:56:16','2026-08-22 17:56:16'),(33,26,17,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 17:56:16','2026-08-22 17:56:16'),(34,27,19,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 17:56:16','2026-08-22 17:56:16'),(35,40,30,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 17:56:16','2026-08-22 17:56:16'),(36,25,15,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 18:07:50','2026-08-22 18:07:50'),(37,25,16,'Wildberries','orders',0,0,'failed','fetch failed','2026-08-22 18:07:50','2026-08-22 18:07:50'),(38,26,17,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 18:07:50','2026-08-22 18:07:50'),(39,27,19,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 18:07:50','2026-08-22 18:07:50'),(40,40,30,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 18:07:50','2026-08-22 18:07:50'),(41,25,15,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 18:10:10','2026-08-22 18:10:10'),(42,25,16,'Wildberries','orders',0,0,'failed','fetch failed','2026-08-22 18:10:10','2026-08-22 18:10:10'),(43,26,17,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 18:10:10','2026-08-22 18:10:10'),(44,27,19,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 18:10:10','2026-08-22 18:10:10'),(45,40,30,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 18:10:10','2026-08-22 18:10:10'),(46,25,15,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 18:39:10','2026-08-22 18:39:10'),(47,25,16,'Wildberries','orders',0,0,'failed','fetch failed','2026-08-22 18:39:10','2026-08-22 18:39:10'),(48,26,17,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 18:39:10','2026-08-22 18:39:10'),(49,27,19,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 18:39:10','2026-08-22 18:39:10'),(50,40,30,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 18:39:10','2026-08-22 18:39:10'),(51,25,15,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 19:09:10','2026-08-22 19:09:10'),(52,25,16,'Wildberries','orders',0,0,'failed','fetch failed','2026-08-22 19:09:10','2026-08-22 19:09:10'),(53,26,17,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 19:09:10','2026-08-22 19:09:10'),(54,27,19,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 19:09:10','2026-08-22 19:09:10'),(55,40,30,'Temu','orders',0,0,'failed','fetch failed','2026-08-22 19:09:10','2026-08-22 19:09:10');
/*!40000 ALTER TABLE `sync_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenants`
--

DROP TABLE IF EXISTS `tenants`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tenants` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `plan` varchar(20) NOT NULL DEFAULT 'trial',
  `status` varchar(20) NOT NULL DEFAULT 'active',
  `expire_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenants`
--

LOCK TABLES `tenants` WRITE;
/*!40000 ALTER TABLE `tenants` DISABLE KEYS */;
INSERT INTO `tenants` VALUES (9,'固始县创宇互联网科技中心(个体工商户)','trial','active','2026-09-05 10:35:45','2026-08-22 10:35:45'),(10,'数序科技（郑州）跨境电商','trial','active','2026-09-05 10:38:54','2026-08-22 10:38:54'),(21,'端到端测试贸易','trial','active','2026-09-05 11:29:14','2026-08-22 11:29:14'),(22,'第二租户','trial','active','2026-09-05 11:29:16','2026-08-22 11:29:16'),(23,'P3P4测试贸易','trial','active','2026-09-05 11:29:17','2026-08-22 11:29:17'),(24,'隔离测试租户','trial','active','2026-09-05 11:29:20','2026-08-22 11:29:20'),(25,'OAuth全量验证','trial','active','2026-09-05 12:00:17','2026-08-22 12:00:17'),(26,'OAuth全量验证','trial','active','2026-09-05 12:00:51','2026-08-22 12:00:51'),(27,'OAuth全量验证','trial','active','2026-09-05 13:22:09','2026-08-22 13:22:09'),(28,'P3P4测试贸易','trial','active','2026-09-05 13:27:37','2026-08-22 13:27:37'),(29,'隔离测试租户','trial','active','2026-09-05 13:27:40','2026-08-22 13:27:40'),(30,'P6功能测试','trial','active','2026-09-05 13:42:17','2026-08-22 13:42:17'),(31,'P6功能测试','trial','active','2026-09-05 13:43:16','2026-08-22 13:43:16'),(32,'P6功能测试','trial','active','2026-09-05 13:43:25','2026-08-22 13:43:25'),(33,'P6功能测试','trial','active','2026-09-05 13:43:47','2026-08-22 13:43:47'),(34,'P3P4测试贸易','trial','active','2026-09-05 13:43:52','2026-08-22 13:43:52'),(35,'隔离测试租户','trial','active','2026-09-05 13:43:54','2026-08-22 13:43:54'),(36,'P3P4测试贸易','trial','active','2026-09-05 13:44:02','2026-08-22 13:44:02'),(37,'隔离测试租户','trial','active','2026-09-05 13:44:04','2026-08-22 13:44:04'),(38,'P3P4测试贸易','trial','active','2026-09-05 13:44:22','2026-08-22 13:44:22'),(39,'隔离测试租户','trial','active','2026-09-05 13:44:24','2026-08-22 13:44:24'),(40,'OAuth全量验证','trial','active','2026-09-05 13:44:25','2026-08-22 13:44:25'),(41,'P6功能测试','trial','active','2026-09-05 13:52:59','2026-08-22 13:52:59'),(42,'验证测试租户','trial','active','2026-09-05 16:02:34','2026-08-22 16:02:34'),(43,'测试公司','trial','active','2026-09-05 16:06:28','2026-08-22 16:06:28'),(44,'浏览器验证','trial','active','2026-09-05 17:45:54','2026-08-22 17:45:54');
/*!40000 ALTER TABLE `tenants` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `tenant_id` bigint(20) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `role` varchar(20) NOT NULL DEFAULT 'owner',
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  KEY `idx_users_tenant` (`tenant_id`)
) ENGINE=InnoDB AUTO_INCREMENT=50 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (9,9,'admin','bfb94803b8562b8d9db8a2e4b904789f:5c849d8745b092ae5bed466e201189fe8a7475065859da176290611c255d8d8c39d9ec8061d08b147ea0a94daabd818db4bd506d171472c58ba5999ff40a4913','owner','2026-08-22 10:35:46'),(10,10,'demo','cfbfc87adace541c625465f881f4971b:d65aa4ffe2cb93481b64e0d206ac26e0d5b86204c85c198d269a15f0f1abea650dcdd2bb3225c56d4553153dc85f8e90843f595642a6f898e97bdf680f78a3ce','owner','2026-08-22 10:38:55'),(21,21,'e2e_test','23a2ee8008ff4d34ebfec0b8475f2f1f:8e921c072532fd6f97049f31a56ae84fabf1280c2cdf1ad101555409c937cb1fcacac57720a7144ec43f9c4cc5c075a2b95f349835edcc1373af77154222d3a6','owner','2026-08-22 11:29:14'),(22,22,'e2e_test2','2ce2bfcb9b4e9896e86da7672550668f:8e7f3919713cf6ae01dc087d57720658015290a01df67ad30d9e47adc110668a36cffbf71dc70b8e42e369626bc51dc553eb7c20c4f3def4c7929212d13c868e','owner','2026-08-22 11:29:16'),(23,23,'e2e_p3_1787369357a','471847f9922d3258de54c21544b58b47:eed8beab1d068829567de25e0922c14abbab438ec34d1f4010bd47025490ae517cd13cf4f9f5ccdb737c2a08f4a139611431a49ac13cc1c457d42d979ef2817a','owner','2026-08-22 11:29:17'),(24,24,'e2e_p3_1787369357b','6b106bcd51d151a94b9b3727bfc2114d:570431891d79a2a949b98b6797bd93b5607d9234992630706162f86e4575150799bf6f56e5cf5732a47aff8964f0e3edbedbe32c14b165344dcf56a3d91c0696','owner','2026-08-22 11:29:20'),(25,25,'e2e_oauth_1787371217','50d8ecb4c3513d027fad5b0879bd97f3:11843c9f3e736f39f0595e5fb6d26db1f8503b36433ddaab1c45ca943414dbfc85a55df460dd597094fdf30ddaf6d85bbf6ce8ed3b575ec875ee7ca4e82fb620','owner','2026-08-22 12:00:17'),(26,26,'e2e_oauth_1787371250','aee9b46f22db3d2bd3cc7ac75b452d32:5b46f87687210a0c0c6a8f2575c93f094777968f7a510404217aa4a76964c270afcc1782fd37b974e0588002a46be12b98b2ea8cd4fb52610faafe03cc3fbbfd','owner','2026-08-22 12:00:51'),(27,27,'e2e_oauth_1787376128','534831ad00dbd10ee369ff1fbe311247:7c402715776eb215b9871c5f02755c11250f7dfec7249e9ddefe9ac38bc70c9c98db1cf92f073a951b0d0c0a59486967b78f607c0cd830899fe59cbfa9b5de4a','owner','2026-08-22 13:22:09'),(28,28,'e2e_p3_1787376457a','6c3d976f356348960d558e94aee70270:175d9db2d23abf2162dc3a7214e2764da229c767adfae6ffd21f0dee2287643b66ff8abcfc4d692f41e10836bf6be84979bcc25a9b8b7e0f438acd65bebd0819','owner','2026-08-22 13:27:37'),(29,29,'e2e_p3_1787376457b','0a868b14984aeeca80acf07b158be4b9:d7115a8e3765420df3eb3c5d69edb6ca77d7a0fe5652dfe9c21559188004eb2f2a5e13d9a429306ab4ef540158a3c34447336eab7fa7cdf8cd79864c31fec5ca','owner','2026-08-22 13:27:40'),(30,30,'p6_1787377337o','02e9eae4427651468d5c9822ad5a46c2:5a45f4f45539db1382b1648101c51dc629254e094939f52900b2cc9fdd1b81fcc91227c02d8d5bffaeb84e38efa6aceb70c69addfab94b173158574cbd614a81','owner','2026-08-22 13:42:17'),(32,31,'p6_1787377396o','d56197a8dc842b4cbb662b8297d57410:54dd8ae6b659756f7367ef1f5a4ab8102c86d78dd61bee3aa18260f5e924df742b7157c9aedc05632a1bfe82caeb95528242900363ee027117c59924b47eb04b','owner','2026-08-22 13:43:17'),(34,32,'p6_1787377405o','bc6380b7b69505ea7e931b22a210bc8c:c5c4c1a33b73482ad30c685e05cd932652c9f3a1e6c35448e367607890a8cf5b69cfbc1779a948c2ad3fde225e1749a261426a8fc34ec34d634dcd3f8e18aa95','owner','2026-08-22 13:43:25'),(36,33,'p6_1787377427o','b86539e09a5dc4931e21f5e23ad913a9:0c122f15d2727de0ac561c45a8e879852cdfb78050b9a45b9f293b5d33535401a13d5072b388b24517193a7aabb573dfd3a05342bad78465884dd8da7aef8d7b','owner','2026-08-22 13:43:47'),(38,34,'e2e_p3_1787377432a','fba8df15ad82677f1c06dfc51963507e:e9639e5fc6ea47d365fd1ab33213b54d6ae0de3c81ccf2fc38bb2e6e8fa3a9299e3149544b8a63ed492581f7a3cec8105ade2d24b6b36ad39ee508c538c10972','owner','2026-08-22 13:43:52'),(39,35,'e2e_p3_1787377432b','89b8f7a2b3766dc5af24870558858dd9:af9fd18e67a24bc57701e10747a76af779937a456be1132065da9f9460b030d0268c2366f64419bf455c12c46abe5f6386a1847b6529bd6f951d69f0d5c6e474','owner','2026-08-22 13:43:54'),(40,36,'e2e_p3_1787377442a','8c8bc85bd3f35fb797541999958dcce5:1aab2b7186145c6847e63422808c7e44e4ca34971150873828b90014c3145c8a8acdf1b8c85dafe043289b5606e8ed197214108402aed2782284eacffd2c32ba','owner','2026-08-22 13:44:02'),(41,37,'e2e_p3_1787377442b','89e71dfc7a4f935d7bcc64dba67c99f1:a1a6a01f29d068a1d6b9a75529d99d3839c6ad7293ac472057c75a2a287e9542698794ec99d2ff92cb6037167eb31564ba2506bb9d1a21eea0e3d617b8e7e02e','owner','2026-08-22 13:44:05'),(42,38,'e2e_p3_1787377462a','3b916c6472700c1deb3ea1a689cd3112:c886527eb8254844e2c29a49186a2776a7122a6dbe9fc936e350e10deefbb20c1fbf24e039d2a0f0602c5f0d2cf057fb824c52761ad7de6381e938f99adc7d32','owner','2026-08-22 13:44:22'),(43,39,'e2e_p3_1787377462b','8c21ae3830e8fd43d1c2784e3aa00cb4:b67362b7849f070c20d681169732214437279f58cfc2894ee3484c9c4deb19e380720c3d24103c0a92376674a9758a42a25194c7935fbba70c9b997917bc2dda','owner','2026-08-22 13:44:24'),(44,40,'e2e_oauth_1787377465','6bd330a7a8e857d2d6913b1656d0bc1d:3275501c36564b84438713491e8fcc9e58ee71ede5f25478f3afcbd585eacc3274a59b83188d33fae839c58c63c9a855d3a8c03d19f5b0a6973fdccf71360b7d','owner','2026-08-22 13:44:25'),(45,41,'p6_1787377979o','00fdd3e6f676ab8d22088cfcf9c4088c:a65e683a8f5591711a798af745996ecf5b433e1b5d1af050477b8d898ad16713c0e7c62abb11af33258b46f3b032a21c6fbd9e90822130ce1b74102c8a1865be','owner','2026-08-22 13:52:59'),(47,42,'verify_test1','1a96521d341cceb92eb59d2c9838f6c1:a81b1abc1299bd101f03e7485abb8873fdb80ed2ef1b699118cb645399b143e354310156e5b3af734fc730b1fc7edcc285c38fd47601336962af504b2c81ad9c','owner','2026-08-22 16:02:34'),(48,43,'testerp','1bf96e7e2e8fa24ad95a5c1a162f07f1:0d718dca11b4e28ea0443d235ed1cc5a9eceef5bd1fbb2205744dd5ce7af5461aaf0cf8f6d7527bcf9edb082fe04fb75ee70d8f6344391e793a0954ea44ce0b8','owner','2026-08-22 16:06:28'),(49,44,'browser_test_1787391954','fdc2409aee2041def098fad567f4eea4:0997154d7a4eec0822c8354e893af989c4368906964d05baea98c20073c8b85059e40c68d05d0ea6339253c63e14ebadb4eba10e3da8531f7eeaa23952d4d6f0','owner','2026-08-22 17:45:54');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'shuxu_erp'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-08-22 19:25:03
