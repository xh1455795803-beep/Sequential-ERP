import React from 'react';

export function WaveTasksPage() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-gray-800">WaveTasksPage</h1>
      <p className="text-gray-500 mt-2">页面开发中...</p>
    </div>
  );
}
