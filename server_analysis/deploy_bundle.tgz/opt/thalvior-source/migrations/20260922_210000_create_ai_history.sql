-- AI 历史记录表：保存每次 AI 调用的输入/输出，供租户查看与删除
CREATE TABLE IF NOT EXISTS public.ai_history (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID,
  service_key TEXT NOT NULL DEFAULT '',
  service_name TEXT NOT NULL DEFAULT '',
  input_text TEXT NOT NULL DEFAULT '',
  output_text TEXT NOT NULL DEFAULT '',
  cost NUMERIC NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT '成功',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.ai_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY users_select_own_ai_history ON public.ai_history
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY users_insert_own_ai_history ON public.ai_history
  FOR INSERT WITH CHECK (user_id = auth.uid());

CREATE POLICY users_update_own_ai_history ON public.ai_history
  FOR UPDATE USING (user_id = auth.uid());

CREATE POLICY users_delete_own_ai_history ON public.ai_history
  FOR DELETE USING (user_id = auth.uid());