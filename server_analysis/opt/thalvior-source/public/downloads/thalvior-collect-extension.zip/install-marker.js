// 安装标记：插件装好后，在 ERP 站点注入一个 DOM 标记，
// 供「扩展坞」面板实时检测「插件是否安装成功 / 当前版本」，把安装流程做成闭环。
// 这是业内通用做法（妙手、店小秘同样靠标记判断是否提示用户装插件）。
// 仅匹配 thalvior.icu 自身域名，不在任何电商站点注入，权限最小。
(function () {
  "use strict";
  try {
    const VERSION = "1.2.0";
    const root = document.documentElement;
    root.setAttribute("data-thalvior-collector", VERSION);
    window.dispatchEvent(new CustomEvent("thalvior:collector-ready", { detail: { version: VERSION } }));
  } catch {
    /* 页面受限时静默失败，不影响插件采集能力 */
  }
})();
