// Thalvior 智能采集插件 —— background service worker
// 快捷键 Alt+S 直接触发采集（免打开 popup）
"use strict";

// ===== 内置服务配置（详见 popup.js 同段说明）=====
const CONFIG = {
  url: "https://thalvior.icu",
  anonKey:
    "eyJhbGciOiAiSFMyNTYiLCAidHlwIjogIkpXVCJ9.eyJyb2xlIjogImFub24iLCAiaXNzIjogInN1cGFiYXNlIiwgImlhdCI6IDE3OTAyNjgwMTYsICJleHAiOiAyMTA1NjI4MDE2fQ.P3s0YUizo985KezDkYZLOSbJGB0_2EaEzLd23MGSsFw",
  appId: "pm45exfrqoja",
};

// token 过期自动续期（与 popup.js 同逻辑）
async function ensureFreshAuth() {
  const store = await chrome.storage.local.get(["auth"]);
  const cfg = CONFIG;
  const { auth } = store;
  if (!auth?.access_token) return { cfg, auth: null };
  try {
    const payload = JSON.parse(atob(auth.access_token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/")));
    const expiresAt = (payload.exp || 0) * 1000;
    if (expiresAt - Date.now() > 2 * 60 * 1000) return store;
    const resp = await fetch(`${cfg.url}/auth/v1/token?grant_type=refresh_token`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: cfg.anonKey },
      body: JSON.stringify({ refresh_token: auth.refresh_token }),
    });
    if (resp.ok) {
      const session = await resp.json();
      const nextAuth = {
        access_token: session.access_token,
        refresh_token: session.refresh_token,
        user_id: session.user?.id || auth.user_id || null,
      };
      await chrome.storage.local.set({ auth: nextAuth });
      return { cfg, auth: nextAuth };
    }
    await chrome.storage.local.set({ auth: null });
    return { cfg, auth: null };
  } catch {
    return { cfg, auth };
  }
}

async function collectAndSave() {
  const { cfg, auth } = await ensureFreshAuth();
  if (!cfg || !auth?.access_token) {
    chrome.action.openPopup?.();
    return;
  }
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;

  // RLS 要求 user_id = auth.uid()，缺了会被拦成 403
  let authed = auth;
  if (!authed.user_id) {
    try {
      const me = await fetch(`${cfg.url}/auth/v1/user`, {
        headers: { apikey: cfg.anonKey, Authorization: `Bearer ${auth.access_token}` },
      });
      if (me.ok) {
        const u = await me.json();
        if (u?.id) {
          authed = { ...auth, user_id: u.id };
          await chrome.storage.local.set({ auth: authed });
        }
      }
    } catch {
      /* ignore */
    }
  }
  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    const res = await chrome.tabs.sendMessage(tab.id, { type: "COLLECT_PAGE" });
    if (!res?.ok) throw new Error(res?.error || "解析失败");
    const item = res.data;
    const resp = await fetch(`${cfg.url}/rest/v1/collect_items`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        apikey: cfg.anonKey,
        Authorization: `Bearer ${auth.access_token}`,
        Prefer: "return=minimal",
      },
      body: JSON.stringify({
        name: item.name,
        source: item.source,
        category: "插件采集",
        price: item.price || null,
        original_price: item.originalPrice || null,
        currency: item.currency || null,
        image: item.image || null,
        images: item.images || [],
        detail_images: item.detailImages || [],
        description: item.description || null,
        sku: item.sku || null,
        brand: item.brand || null,
        seller: item.seller || null,
        rating: item.rating || null,
        reviews: item.reviews || null,
        sales: item.sales || null,
        variants: item.variants || [],
        platform: item.platform || null,
        status: "待处理",
        user_id: authed.user_id || null,
      }),
    });
    if (!resp.ok) throw new Error(`入库失败 (${resp.status})`);
    // badge 反馈 1.5s
    await chrome.action.setBadgeText({ text: "✓" });
    await chrome.action.setBadgeBackgroundColor({ color: "#1F7A4D" });
    setTimeout(() => chrome.action.setBadgeText({ text: "" }), 1500);
  } catch (e) {
    await chrome.action.setBadgeText({ text: "!" });
    await chrome.action.setBadgeBackgroundColor({ color: "#B3382C" });
    setTimeout(() => chrome.action.setBadgeText({ text: "" }), 1500);
  }
}

chrome.commands.onCommand.addListener((command) => {
  if (command === "collect-current-page") collectAndSave();
});
