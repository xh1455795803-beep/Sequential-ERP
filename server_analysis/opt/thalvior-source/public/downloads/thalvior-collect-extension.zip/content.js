// Thalvior 智能采集插件 —— content script
// 在商品页 DOM 中提取完整商品数据（插件在浏览器内运行，带登录态，可突破云函数抓取限制）
//
// 平台覆盖：Amazon / eBay / AliExpress / Temu / Shopee / Lazada / Wish / Shein
//           / 1688 / 淘宝 / 天猫 / 京东 / 拼多多 / 通用站点
// 每个平台都输出统一字段：标题、品牌、卖家、价格、原价、币种、主图、图集、详情图、
// SKU 变体、评分、评论数、销量、描述、来源链接。
(function () {
  "use strict";

  const decode = (s) =>
    String(s || "")
      .replace(/&amp;/g, "&")
      .replace(/&lt;/g, "<")
      .replace(/&gt;/g, ">")
      .replace(/&quot;/g, '"')
      .replace(/&#39;|&apos;/g, "'")
      .replace(/&nbsp;/g, " ")
      .replace(/\s+/g, " ")
      .trim();

  const toPrice = (raw) => {
    const n = Number(String(raw || "").replace(/[^0-9.,]/g, "").replace(/,(?=\d{3}\b)/g, "").replace(",", "."));
    return Number.isFinite(n) ? n : 0;
  };
  const toInt = (raw) => Number(String(raw || "").replace(/[^\d]/g, "")) || 0;

  const q = (sel) => document.querySelector(sel);
  const qa = (sel) => Array.from(document.querySelectorAll(sel));

  // ===== 图片工具 =====
  // 排除 logo / 图标 / 占位图 / 广告位等噪声图
  const IMG_NOISE = /logo|icon|sprite|placeholder|loading|avatar|banner|advert|promo|grey-pixel|transparent-pixel|1x1|blank|rating|star-|flag-|flag_|feedback|trust|secure|payment|shipping|country|language/i;

  /** 归一化图片 URL：补协议、去掉电商平台的缩略图尺寸后缀以拿到原图 */
  function normalizeImg(u) {
    if (!u || typeof u !== "string") return "";
    let url = u.trim();
    if (url.startsWith("//")) url = location.protocol + url;
    if (url.startsWith("data:")) return "";
    let protocol = "";
    if (url.startsWith("https://")) protocol = "https://";
    else if (url.startsWith("http://")) protocol = "http://";
    if (!protocol) return "";
    let rest = url.slice(protocol.length);
    // 丢弃 query，避免带签名的临时链接
    const hashIdx = rest.indexOf("#");
    if (hashIdx > -1) rest = rest.slice(0, hashIdx);
    if (rest.includes("?")) rest = rest.slice(0, rest.indexOf("?"));
    // 阿里系：img.xxx.jpg_400x400q90.jpg → img.xxx.jpg
    if (/_[a-z]*\d+x\d+[a-z]*\.(jpg|jpeg|png|webp)$/i.test(rest)) {
      rest = rest.replace(/_[a-z]*\d+x\d+[a-z]*\.(jpg|jpeg|png|webp)$/i, ".$1");
    }
    // Shopify/Amazon 常见尺寸后缀：xxx_400x400.jpg、xxx._AC_SL400_.jpg
    rest = rest.replace(/_[a-z]{0,4}\d{2,4}x\d{2,4}[a-z]{0,4}\.(jpg|jpeg|png|webp)$/i, ".$1");
    rest = rest.replace(/\._[A-Z]{2}_[A-Z]{2}\d+_\.(jpg|jpeg|png|webp)$/i, ".$1");
    return protocol + rest;
  }

  /** 从一组 img 元素提取图片 URL（过滤 + 去重 + 上限） */
  function pickImages(nodes, limit) {
    const seen = new Set();
    const out = [];
    for (const img of nodes) {
      const raw =
        img.getAttribute("data-src") ||
        img.getAttribute("data-lazy-src") ||
        img.getAttribute("data-original") ||
        img.getAttribute("data-old-hires") ||
        img.getAttribute("srcset")?.split(",")[0]?.trim().split(" ")[0] ||
        img.src ||
        "";
      const url = normalizeImg(raw);
      if (!url) continue;
      if (IMG_NOISE.test(url)) continue;
      // 跳过明显的小图标
      if (img.naturalWidth && img.naturalWidth < 80 && img.naturalHeight && img.naturalHeight < 80) continue;
      const key = url.split("/").pop().slice(0, 60) + "|" + url.length;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(url);
      if (out.length >= limit) break;
    }
    return out;
  }

  /** 详情图：跨平台通用选择器，这是上架 Listing 的关键素材 */
  const DETAIL_SELECTORS = [
    "#aplus", "#aplus_feature_div", "#productDescription", "#productDetails_detailBullets_sections1",
    "#J_DivItemDesc", "#description", "#desc_div", "#vi-desc-maincntr",
    ".product-detail", ".detail-content", ".goods-detail", ".prod-detail", ".rte",
    "[id*='Description']", "[id*='description']",
    "[class*='Description']", "[class*='description-content']", "[class*='description']", "[class*='DetailDesc']",
    "[class*='product-detail']", "[class*='goodDetail']", "[class*='detailContent']",
    "[class*='detail-content']", "[class*='richText']", "[data-module*='detail']",
  ];

  function pickDetailImages() {
    const nodes = [];
    for (const sel of DETAIL_SELECTORS) {
      try {
        for (const el of qa(sel).slice(0, 3)) {
          for (const img of el.querySelectorAll("img")) nodes.push(img);
        }
      } catch {
        /* 选择器不兼容时跳过 */
      }
      if (nodes.length >= 80) break;
    }
    return pickImages(nodes, 40);
  }

  // ===== 币种识别 =====
  const TLD_CURRENCY = {
    // Amazon 各站点
    "amazon.com": "USD", "amazon.ca": "CAD", "amazon.com.mx": "MXN", "amazon.com.br": "BRL",
    "amazon.co.uk": "GBP", "amazon.de": "EUR", "amazon.fr": "EUR", "amazon.it": "EUR",
    "amazon.es": "EUR", "amazon.nl": "EUR", "amazon.se": "SEK", "amazon.pl": "PLN",
    "amazon.co.jp": "JPY", "amazon.com.au": "AUD", "amazon.sg": "SGD", "amazon.ae": "AED",
    "amazon.sa": "SAR", "amazon.in": "INR",
  };

  function detectCurrency() {
    const host = location.hostname.replace(/^www\./, "");
    for (const [domain, cur] of Object.entries(TLD_CURRENCY)) {
      if (host === domain || host.endsWith("." + domain)) return cur;
    }
    if (/1688\.com$|taobao\.com$|tmall\.com$|jd\.com$|pinduoduo\.com$|yangkeduo\.com$/.test(host)) return "CNY";
    if (/ebay\.(co\.uk|com\.au)$/.test(host)) return /uk/.test(host) ? "GBP" : "AUD";
    if (/ebay\.(de|fr|it|es)$/.test(host)) return "EUR";
    if (/ebay\.com$|ebay\.ca$/.test(host)) return "USD";
    if (/shopee\.(tw|th|ph|vn|my|sg|id|br)$/.test(host)) {
      return { tw: "TWD", th: "THB", ph: "PHP", vn: "VND", my: "MYR", sg: "SGD", id: "IDR", br: "BRL" }[RegExp.$1] || "USD";
    }
    if (/lazada\./.test(host)) return host.includes(".vn") ? "VND" : host.includes(".th") ? "THB" : "MYR";
    // 兜底：从页面正文的货币符号推断
    const txt = (q("body")?.innerText || "").slice(0, 30000);
    if (/US\$|\$\s?\d/.test(txt)) return "USD";
    if (/￥|RMB|¥\s?\d/.test(txt)) return "CNY";
    if (/£\s?\d/.test(txt)) return "GBP";
    if (/€\s?\d/.test(txt)) return "EUR";
    return "USD";
  }

  // ===== JSON-LD Product =====
  function fromJsonLd() {
    try {
      const scripts = qa('script[type="application/ld+json"]');
      for (const s of scripts) {
        let data;
        try {
          data = JSON.parse(s.textContent);
        } catch {
          continue;
        }
        const nodes = Array.isArray(data) ? data : data["@graph"] ? data["@graph"] : [data];
        for (const n of nodes) {
          const p = n && n["@type"] === "Product" ? n : null;
          if (!p) continue;
          const offers = Array.isArray(p.offers) ? p.offers[0] : p.offers;
          return {
            name: decode(p.name),
            description: decode(p.description),
            brand: decode(typeof p.brand === "string" ? p.brand : p.brand?.name),
            sku: decode(p.sku || p.mpn || p.gtin13 || ""),
            image: normalizeImg(typeof p.image === "string" ? p.image : Array.isArray(p.image) ? p.image[0] : ""),
            images: pickImages(typeof p.image === "string" ? [] : [], 0),
            price: toPrice(offers?.price || offers?.lowPrice),
            currency: offers?.priceCurrency || "",
            rating: Number(p.aggregateRating?.ratingValue) || 0,
            reviews: Number(p.aggregateRating?.reviewCount || p.aggregateRating?.ratingCount) || 0,
          };
        }
      }
    } catch {
      /* ignore */
    }
    return null;
  }

  // ===== 平台解析器 =====
  function fromAmazon() {
    const out = { platform: "Amazon" };
    out.name = decode(q("#productTitle")?.textContent);
    out.price = toPrice(q(".a-price .a-offscreen")?.textContent || q("#priceblock_ourprice")?.textContent);
    const listPrice = qa(".a-price.a-text-price .a-offscreen").map((x) => toPrice(x.textContent));
    if (listPrice.length > 0) out.originalPrice = Math.max(...listPrice);
    const landing = q("#landingImage");
    out.image = normalizeImg(landing?.dataset?.oldHires || landing?.dataset?.hires || landing?.src);
    out.images = pickImages(qa("#altImages img, #imageBlock img, .imageThumb img"), 12);
    const alt = q("#acrPopover")?.title || q(".a-icon-alt")?.textContent || "";
    const ratingMatch = alt.match(/([\d.]+) out of 5/);
    if (ratingMatch) out.rating = Number(ratingMatch[1]);
    out.reviews = toInt(q("#acrCustomerReviewText")?.textContent);
    out.seller = decode(q("#sellerProfileTriggerId")?.textContent || q("#bylineInfo")?.textContent);
    out.brand = decode(q("#bylineInfo")?.textContent)?.replace(/^(Visit the|Brand:)\s*/i, "").replace(/\s*Store$/, "");
    out.variants = qa("#twister .swatchElement input, #twister li")
      .slice(0, 50)
      .map((el, i) => ({
        name: decode(el.getAttribute("title") || el.getAttribute("aria-label") || el.textContent || `变体${i + 1}`),
        sku: el.getAttribute("data-defaultasin") || "",
        price: out.price || 0,
        image: "",
        stock: 0,
      }));
    return out;
  }

  function from1688() {
    const out = { platform: "1688", currency: "CNY" };
    out.name = decode(q("h1.title-text")?.textContent) || decode(q(".object-title")?.textContent);
    out.price = toPrice(q(".price-text, .value, [class*='price']")?.textContent);
    out.image = normalizeImg(q("img.main-image, .od-image-gallery img")?.src || q("video")?.poster);
    out.images = pickImages(qa(".od-image-gallery img, .thumb-list img, [class*='imageGallery'] img"), 12);
    out.seller = decode(q(".company-name, .shop-name")?.textContent);
    out.sales = toInt(q(".sell-count, [class*='sold']")?.textContent);
    out.variants = qa(".sku-item, .unit-shape-item, [class*='skuItem']")
      .slice(0, 50)
      .map((el, i) => ({
        name: decode(el.textContent || `规格${i + 1}`),
        sku: el.dataset?.skuid || "",
        price: toPrice(el.querySelector("[class*='price']")?.textContent) || out.price || 0,
        image: normalizeImg(el.querySelector("img")?.src),
        stock: 0,
      }));
    return out;
  }


  // ── 1688 精确提取：解析 window.context(result.data)（subject/mainImage/skuProps/skuMap/卖家/件重尺）──
  function extractBalanced(text, startIdx) {
    let depth = 0, inStr = false, esc = false;
    for (let i = startIdx; i < text.length; i++) {
      const c = text[i];
      if (inStr) {
        if (esc) esc = false;
        else if (c === "\\") esc = true;
        else if (c === '"') inStr = false;
        continue;
      }
      if (c === '"') { inStr = true; continue; }
      if (c === "[" || c === "{") depth++;
      else if (c === "]" || c === "}") {
        depth--;
        if (depth === 0) return text.slice(startIdx, i + 1);
      }
    }
    return null;
  }
  function takeBalanced(text, key) {
    const i = text.indexOf('"' + key + '":');
    if (i < 0) return null;
    let j = i + key.length + 3;
    while (j < text.length && /\s/.test(text[j])) j++;
    if (text[j] !== "[" && text[j] !== "{") return null;
    return extractBalanced(text, j);
  }
  function extract1688() {
    const out = { sourceName: "1688-context" };
    let st = "";
    for (const s of qa("script")) {
      const t = s.textContent || "";
      if (t.includes("window.context") && t.includes('"result"')) { st = t; break; }
    }
    if (!st) return null;
    const js = st.indexOf(',{"result":');
    if (js < 0) return null;
    const seg = st.slice(js + 1, js + 1 + 200000);
    const subj = seg.match(/"subject":"((?:[^"\\]|\\.)*)"/);
    if (subj) out.title = subj[1];
    const pd = seg.match(/"priceDisplay":"([^"]*)"/);
    if (pd && toPrice(pd[1]) != null) out.price = toPrice(pd[1]);
    else {
      const cp = seg.match(/"currentPrices":\[([^\]]{0,300})\]/);
      if (cp) {
        const m = cp[1].match(/"price":"([^"]*)"/);
        if (m) out.price = toPrice(m[1]);
      }
    }
    const mi = takeBalanced(seg, "mainImage");
    if (mi) {
      try {
        const arr = JSON.parse(mi);
        const imgs = arr.filter((u) => typeof u === "string" && /^https?:\/\//i.test(u));
        if (imgs.length) out.images = imgs.slice(0, 30);
      } catch { /* ignore */ }
    }
    const sp = takeBalanced(seg, "skuProps");
    if (sp) {
      try {
        const props = JSON.parse(sp);
        out.specs = props
          .map((p) => ({
            name: p.prop || p.label || "",
            values: (p.value || []).map((v) => (typeof v === "string" ? v : v.name || v.value || "")).filter(Boolean),
          }))
          .filter((p) => p.name || p.values.length)
          .slice(0, 20);
      } catch { /* ignore */ }
    }
    const sm = takeBalanced(seg, "skuMap");
    if (sm) {
      try {
        const skus = JSON.parse(sm);
        out.skus = skus
          .map((s) => ({
            spec: s.specAttrs || "",
            price: toPrice(s.price != null ? s.price : s.discountPrice),
            stock: Number(s.canBookCount ?? s.stock ?? 0),
            skuId: String(s.skuId ?? ""),
          }))
          .slice(0, 100);
      } catch { /* ignore */ }
    }
    const seller = seg.match(/"frontSellerLoginId":"([^"]*)"/);
    if (seller) out.shopName = seller[1];
    const oid = seg.match(/"offerId":(\d{5,})/);
    if (oid) out.sku = oid[1];
    const pws = takeBalanced(seg, "pieceWeightScaleInfo");
    if (pws) {
      try {
        const arr = JSON.parse(pws);
        if (arr.length && typeof arr[0] === "object") {
          const first = arr[0];
          if (Number(first.weight ?? 0)) out.weight = Number(first.weight);
          if (Number(first.length ?? 0)) out.length = Number(first.length);
          if (Number(first.width ?? 0)) out.width = Number(first.width);
          if (Number(first.height ?? 0)) out.height = Number(first.height);
        }
      } catch { /* ignore */ }
    }
    return out.title || out.images?.length ? out : null;
  }

  function fromTaobao() {
    const out = { platform: location.hostname.includes("tmall") ? "Tmall" : "Taobao", currency: "CNY" };
    out.name = decode(q("h1")?.textContent || q("h3.tb-main-title")?.textContent || q("[class*='ItemTitle']")?.textContent);
    out.price = toPrice(q("[class*='highlightPrice']")?.textContent || q(".tm-price")?.textContent || q("[class*='price']")?.textContent);
    out.image = normalizeImg(q("#J_ImgBooth, .main-pic img, [class*='mainPic'] img")?.src);
    out.images = pickImages(qa("#J_UlThumb li img, [class*='thumbnails'] img, [class*='Thumbnail'] img"), 12);
    out.seller = decode(q(".tb-shop-name, .slogo-shopname strong, [class*='shopName']")?.textContent);
    out.sales = toInt(q("[class*='sold-text'], .tb-sell-counter")?.textContent);
    return out;
  }

  function fromAliExpress() {
    const out = { platform: "AliExpress", currency: "USD" };
    out.name = decode(q("h1.product-title-text, [class*='ProductTitle']")?.textContent || q("h1")?.textContent);
    out.price = toPrice(q(".product-price-value, [class*='uniformBannerBoxPrice'], [class*='price--current']")?.textContent);
    out.originalPrice = toPrice(q("[class*='price--original'], .product-price-del")?.textContent);
    out.image = normalizeImg(q("img.magnifier--image, [class*='ImageSlider'] img, [class*='gallery--item'] img")?.src);
    out.images = pickImages(qa("[class*='ImageSlider'] img, .image-view--previewWrap img, [class*='gallery--item'] img"), 12);
    out.sales = toInt(q("[class*='trade--sold'], [class*='sold-count']")?.textContent);
    out.variants = qa("[class*='skuItem'], .sku-property-item")
      .slice(0, 50)
      .map((el, i) => ({
        name: decode(el.getAttribute("title") || el.textContent || `SKU${i + 1}`),
        sku: "",
        price: 0,
        image: normalizeImg(el.querySelector("img")?.src),
        stock: 0,
      }));
    return out;
  }

  function fromEbay() {
    const out = { platform: "eBay" };
    out.name = decode(q("h1.x-item-title__mainTitle span, h1#itemTitle")?.textContent || q("h1")?.textContent);
    out.price = toPrice(q(".x-price-primary span, #prcIsum, .notranslate")?.textContent);
    out.originalPrice = toPrice(q(".x-price-strikethrough span, #orgPrc")?.textContent);
    out.image = normalizeImg(q("#icImg, .ux-image-carousel-item img")?.src);
    out.images = pickImages(qa(".ux-image-carousel-item img, #vi_main_img_fs img, .image-treatment img"), 12);
    out.seller = decode(q("[class*='seller-info'] a, #mbgLink")?.textContent);
    out.reviews = toInt(q("[class*='reviews-count'], .ux-summary__start a")?.textContent);
    out.sales = toInt(q("[class*='sold-count'], [class*='item-sold']")?.textContent);
    out.variants = qa("[class*='msku-swatch'], [class*=' variation-value'], .ux-swatch-item, select[name*='variation'] option")
      .slice(0, 50)
      .map((el, i) => ({
        name: decode(el.getAttribute("title") || el.getAttribute("aria-label") || el.textContent || `选项${i + 1}`),
        sku: el.getAttribute("value") || el.dataset?.sku || "",
        price: out.price || 0,
        image: normalizeImg(el.querySelector?.("img")?.src),
        stock: 0,
      }));
    return out;
  }

  function fromTemu() {
    const out = { platform: "Temu" };
    out.name = decode(q("h1, [class*='title-text'], [class*='goods-title']")?.textContent || q("h1")?.textContent);
    out.price = toPrice(q("[class*='price-current'], [class*='PriceCurrent'], .pdc-price")?.textContent);
    out.originalPrice = toPrice(q("[class*='price-original'], [class*='PriceOriginal']")?.textContent);
    out.image = normalizeImg(q("[class*='goods-img'] img, [class*='banner-slide'] img, img")?.src);
    out.images = pickImages(qa("[class*='goods-img'] img, [class*='banner-slide'] img, [class*='thumb'] img"), 12);
    out.variants = qa("[class*='sku-item'], [class*='skuItem'], [class*='goods-property']")
      .slice(0, 50)
      .map((el, i) => ({
        name: decode(el.textContent || `SKU${i + 1}`),
        sku: "",
        price: 0,
        image: normalizeImg(el.querySelector("img")?.src),
        stock: 0,
      }));
    return out;
  }

  function fromShopee() {
    const out = { platform: "Shopee" };
    out.name = decode(q("[class*='qaNIZv'], h1, [class*='product-detail'] h1")?.textContent || q("h1")?.textContent);
    out.price = toPrice(q("[class*='pqTWkA'], [class*='price'], .YkKjVv")?.textContent);
    out.originalPrice = toPrice(q("[class*='original-price'], [class*='CGGiLt']")?.textContent);
    out.image = normalizeImg(q("[class*='_2mgJnZ'] img, [class*='product-image'] img, img")?.src);
    out.images = pickImages(qa("[class*='product-image'] img, [class*='_2mgJnZ'] img, [class*='thumbnail'] img"), 12);
    out.rating = Number(q("[class*='product-rating'] [class*='rating-star']")?.textContent?.trim()) || toInt(q("[class*='rating-star']")?.getAttribute("aria-label"));
    out.sales = toInt(q("[class*='product-review'] [class*='sold'], [class*='_3bJvQi']")?.textContent);
    out.variants = qa("[class*='product-variation'], [class*='variation']")
      .slice(0, 50)
      .map((el, i) => ({
        name: decode(el.textContent || `SKU${i + 1}`),
        sku: "",
        price: 0,
        image: normalizeImg(el.querySelector("img")?.src),
        stock: 0,
      }));
    return out;
  }

  function fromLazada() {
    const out = { platform: "Lazada" };
    out.name = decode(q("#pdp-title, h1")?.textContent || q("h1")?.textContent);
    out.price = toPrice(q(".pdp-price_size_l, [class*='pdp-price'], #module_product_price_1")?.textContent);
    out.originalPrice = toPrice(q(".pdp-price_type_deleted, [class*='origin-price']")?.textContent);
    out.image = normalizeImg(q(".gallery-preview-panel img, #module_item_gallery_1 img, img")?.src);
    out.images = pickImages(qa(".gallery-preview-panel img, .item-gallery img, [class*='gallery'] img"), 12);
    out.seller = decode(q("[class*='seller-name'], #module_seller_info a")?.textContent);
    out.rating = Number(q("[class*='rating'], .score")?.textContent?.trim()) || 0;
    out.variants = qa("[class*='sku-prop'] .sku-prop-content, .pdp-product-sku [class*='item'], [class*='attributeItem']")
      .slice(0, 50)
      .map((el, i) => ({
        name: decode(el.getAttribute("title") || el.textContent || `选项${i + 1}`),
        sku: "",
        price: 0,
        image: normalizeImg(el.querySelector("img")?.src),
        stock: 0,
      }));
    return out;
  }

  function fromJD() {
    const out = { platform: "京东", currency: "CNY" };
    out.name = decode(q(".sku-name, h1")?.textContent || q("h1")?.textContent);
    out.price = toPrice(q(".p-price .price, .J-p-price")?.textContent);
    out.image = normalizeImg(q("#spec-img, #bigImg")?.src);
    out.images = pickImages(qa("#spec-list img, .lh li img"), 12);
    out.seller = decode(q(".J-hove-wrap .name a, [class*='shopName']")?.textContent);
    out.variants = qa("#choose-attr-1 .item, #choose-attr-2 .item, .J_Prop .item, .li.item")
      .slice(0, 50)
      .map((el, i) => ({
        name: decode(el.textContent || el.getAttribute("data-value") || `选项${i + 1}`),
        sku: el.getAttribute("data-sku") || "",
        price: out.price || 0,
        image: normalizeImg(el.querySelector("img")?.src),
        stock: 0,
      }));
    return out;
  }

  function fromGeneric() {
    const out = { platform: "Web" };
    out.name = decode(
      q('meta[property="og:title"]')?.content ||
      q("h1")?.textContent ||
      document.title.split(/[-–|]/)[0]
    );
    out.price = toPrice(q('[class*="price" i]')?.textContent || q('meta[property="product:price:amount"]')?.content);
    out.image = normalizeImg(q('meta[property="og:image"]')?.content || q("img")?.src);
    out.images = pickImages(qa('meta[property="og:image"]').map((m) => ({ src: m.content })), 12);
    out.description = decode(q('meta[name="description"]')?.content || q('meta[property="og:description"]')?.content);
    return out;
  }

  // ===== 平台调度 =====
  function collectFromPage() {
    const host = location.hostname.replace(/^www\./, "");
    let data;

    if (/^amazon\./i.test(host)) data = { ...fromAmazon() };
    else if (/1688\.com$/i.test(host)) {
      data = { ...fromGeneric(), ...from1688() };
      // 精确提取：解析 window.context 数据（标题/价格/主图/SKU 价格库存/件重尺）
      const e1688 = extract1688();
      if (e1688) {
        if (e1688.title) data.name = e1688.title;
        if (e1688.price != null && e1688.price > 0) data.price = e1688.price;
        if (Array.isArray(e1688.images) && e1688.images.length) {
          data.images = Array.from(new Set(e1688.images.map(normalizeImg).filter(Boolean))).slice(0, 20);
          data.image = data.images[0];
        }
        if (e1688.shopName) data.seller = e1688.shopName;
        if (e1688.sku) data.sku = e1688.sku;
        if (Array.isArray(e1688.skus) && e1688.skus.length) {
          data.variants = e1688.skus.map((s) => ({
            name: decode(s.spec || "规格"),
            sku: String(s.skuId || ""),
            price: Number(s.price) || data.price || 0,
            image: "",
            stock: Number(s.stock) || 0,
          })).slice(0, 50);
        }
        if (Array.isArray(e1688.specs) && e1688.specs.length) data.specGroups = e1688.specs;
        if (e1688.weight != null) data.weight = e1688.weight;
        if (e1688.length != null) data.length = e1688.length;
        if (e1688.width != null) data.width = e1688.width;
        if (e1688.height != null) data.height = e1688.height;
      }
    }
    else if (/taobao\.com$|tmall\.com$/i.test(host)) data = { ...fromGeneric(), ...fromTaobao() };
    else if (/jd\.com$/i.test(host)) data = { ...fromGeneric(), ...fromJD() };
    else if (/pinduoduo\.com$|yangkeduo\.com$/i.test(host)) data = { ...fromGeneric(), platform: "拼多多", currency: "CNY" };
    else if (/aliexpress\./i.test(host)) data = { ...fromGeneric(), ...fromAliExpress() };
    else if (/ebay\./i.test(host)) data = { ...fromGeneric(), ...fromEbay() };
    else if (/temu\.com$/i.test(host)) data = { ...fromGeneric(), ...fromTemu() };
    else if (/shopee\./i.test(host)) data = { ...fromGeneric(), ...fromShopee() };
    else if (/lazada\./i.test(host)) data = { ...fromGeneric(), ...fromLazada() };
    else if (/wish\.com$/i.test(host)) data = { ...fromGeneric(), platform: "Wish" };
    else if (/shein\.com$/i.test(host)) data = { ...fromGeneric(), platform: "SHEIN" };
    else data = fromGeneric();

    // JSON-LD 补缺
    const ld = fromJsonLd();
    if (ld) {
      data.name = data.name || ld.name;
      data.price = data.price || ld.price;
      data.image = data.image || ld.image;
      data.description = data.description || ld.description;
      data.sku = data.sku || ld.sku;
      data.brand = data.brand || ld.brand;
      data.rating = data.rating || ld.rating;
      data.reviews = data.reviews || ld.reviews;
      if (ld.currency) data.currency = data.currency || ld.currency;
    }

    // ===== 统一收尾 =====
    if (!data.currency) data.currency = detectCurrency();
    if (!data.images || data.images.length === 0) data.images = data.image ? [data.image] : [];
    if (!data.image && data.images.length > 0) data.image = data.images[0];
    data.images = Array.from(new Set(data.images)).slice(0, 20);

    // 详情图：平台没抓到就用通用兜底，保证上架素材完整
    let detail = Array.isArray(data.detailImages) ? data.detailImages.filter(Boolean) : [];
    if (detail.length === 0) detail = pickDetailImages();
    // 详情图与图集去重
    const mainSet = new Set(data.images);
    detail = detail.filter((u) => !mainSet.has(u));
    data.detailImages = Array.from(new Set(detail)).slice(0, 40);

    data.variants = Array.isArray(data.variants) ? data.variants.filter((v) => v && v.name).slice(0, 50) : [];
    data.rating = data.rating || 0;
    data.reviews = data.reviews || 0;
    data.sales = data.sales || 0;
    data.originalPrice = data.originalPrice || 0;
    data.description = decode(data.description || q('meta[name="description"]')?.content || "").slice(0, 5000);

    return {
      ...data,
      name: data.name || "未命名商品",
      source: location.href,
      collectedAt: new Date().toISOString(),
    };
  }

  // ===== 列表页批量采集 =====
  function collectListingLinks() {
    const hrefs = new Set();
    const selectors = [
      'a[href*="detail.1688.com/offer/"]',
      'a[href*="/offer/"]',
      'a[href*="taobao.com/item.htm"]',
      'a[href*="tmall.com/item.htm"]',
      'a[href*="/dp/"]',
      'a[href*="/gp/product/"]',
      'a[href*="/item/i."]',
      'a[href*="/itm/"]',
      'a[href*="/product/"]',
      'a[href*="item.jd.com"]',
      'a[href*="-i."]',
      'a[href*="/products/"]',
      'a[href*="/ip/"]',
    ];
    for (const sel of selectors) {
      try {
        for (const a of qa(sel)) {
          const href = a.href;
          if (!href || !href.startsWith("http")) continue;
          try {
            const u = new URL(href);
            if (u.hostname === location.hostname && /\/(cart|login|signin|account|checkout)/i.test(u.pathname)) continue;
            // Amazon：必须是商品页 /dp/ 形式
            if (/amazon\./.test(u.hostname) && !/\/(dp|gp\/product)\/[A-Z0-9]{10}/.test(u.pathname)) continue;
            // eBay：/itm/ 形式
            if (/ebay\./.test(u.hostname) && !/\/itm\//.test(u.pathname)) continue;
            if (/1688\.com$/.test(u.hostname.replace(/^www\./, "")) && !/\/offer\/\d+/.test(u.pathname)) continue;
            if (/taobao\.com$|tmall\.com$/.test(u.hostname.replace(/^www\./, "")) && !/\/item\.htm/.test(u.pathname)) continue;
            if (/jd\.com$/.test(u.hostname) && !/item\.jd\.com/.test(u.hostname)) continue;
          } catch {
            continue;
          }
          hrefs.add(href.split("?")[0] || href);
        }
      } catch {
        /* ignore */
      }
      if (hrefs.size >= 60) break;
    }
    return Array.from(hrefs).slice(0, 60);
  }

  // ===== 消息入口 =====
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg?.type === "COLLECT_PAGE") {
      try {
        sendResponse({ ok: true, data: collectFromPage() });
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
    }
    if (msg?.type === "COLLECT_LISTING") {
      try {
        const links = collectListingLinks();
        const isProductPage = !!document.querySelector(
          "#productTitle, .title-text, [class*='ProductTitle'], #pdp-title, .sku-name"
        );
        sendResponse({ ok: true, links, isProductPage });
      } catch (e) {
        sendResponse({ ok: false, error: String(e) });
      }
    }
    return true;
  });
})();
