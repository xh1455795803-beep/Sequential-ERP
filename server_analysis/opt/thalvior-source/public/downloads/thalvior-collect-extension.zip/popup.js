// Thalvior 智能采集插件 —— popup 逻辑
// 服务地址与公开匿名密钥直接内置（它们本就是前端公开信息），用户只需账号密码即可登录。
"use strict";

const $ = (id) => document.getElementById(id);

// ===== 内置服务配置 =====
// 服务地址与 anon 匿名密钥本就是前端公开信息（同样写在 ERP 前端 JS 里），内置后可免去用户手动配置。
// 真正敏感的数据（用户的 access_token）只存在用户自己的 chrome.storage.local 中。
const CONFIG = {
  url: "https://thalvior.icu",
  anonKey:
    "eyJhbGciOiAiSFMyNTYiLCAidHlwIjogIkpXVCJ9.eyJyb2xlIjogImFub24iLCAiaXNzIjogInN1cGFiYXNlIiwgImlhdCI6IDE3OTAyNjgwMTYsICJleHAiOiAyMTA1NjI4MDE2fQ.P3s0YUizo985KezDkYZLOSbJGB0_2EaEzLd23MGSsFw",
  appId: "pm45exfrqoja",
};

// ===== Supabase REST 极简客户端（无依赖） =====
async function sbLogin(cfg, account, password) {
  const isEmail = account.includes("@");
  const body = isEmail ? { email: account, password } : { phone: account.startsWith("+") ? account : `+86${account}`, password };
  const resp = await fetch(`${cfg.url}/auth/v1/token?grant_type=password`, {
    method: "POST",
    headers: { "Content-Type": "application/json", apikey: cfg.anonKey },
    body: JSON.stringify(body),
  });
  const data = await resp.json();
  if (!resp.ok) throw new Error(data.error_description || data.msg || "登录失败");
  return data; // { access_token, refresh_token, user }
}

async function sbInsertCollect(cfg, token, userId, item) {
  const resp = await fetch(`${cfg.url}/rest/v1/collect_items`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: cfg.anonKey,
      Authorization: `Bearer ${token}`,
      Prefer: "return=minimal",
    },
    body: JSON.stringify({
      name: item.name,
      source: item.source,
      category: "插件采集",
      price: item.price || null,
      original_price: item.originalPrice || null,
      currency: item.currency || null,
      image: item.image || null,
      images: item.images || [],
      detail_images: item.detailImages || [],
      description: item.description || null,
      sku: item.sku || null,
      brand: item.brand || null,
      seller: item.seller || null,
      rating: item.rating || null,
      reviews: item.reviews || null,
      sales: item.sales || null,
      variants: item.variants || [],
      platform: item.platform || null,
      status: "待处理",
      user_id: userId,
    }),
  });
  if (!resp.ok) {
    const errText = await resp.text();
    throw new Error(`入库失败 (${resp.status}): ${errText.slice(0, 120)}`);
  }
}

// ===== 配置与登录态管理 =====
async function getStore() {
  const s = await new Promise((resolve) => chrome.storage.local.get(["auth", "userEmail"], resolve));
  // cfg 一律使用内置服务配置，不再要求用户粘贴任何配置串
  return { ...s, cfg: CONFIG };
}
async function setStore(obj) {
  return new Promise((resolve) => chrome.storage.local.set(obj, resolve));
}

// ===== token 刷新：access_token 1 小时过期，过期自动用 refresh_token 续期 =====
async function ensureFreshAuth() {
  const store = await getStore();
  const { cfg, auth } = store;
  if (!cfg || !auth?.access_token) return store;

  // 解析 JWT exp（秒级时间戳）
  try {
    const payload = JSON.parse(atob(auth.access_token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/")));
    const expiresAt = (payload.exp || 0) * 1000;
    // 剩余 > 2 分钟则直接用
    if (expiresAt - Date.now() > 2 * 60 * 1000) return store;

    // 用 refresh_token 换新
    const resp = await fetch(`${cfg.url}/auth/v1/token?grant_type=refresh_token`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: cfg.anonKey },
      body: JSON.stringify({ refresh_token: auth.refresh_token }),
    });
    if (resp.ok) {
      const session = await resp.json();
      const next = {
        ...store,
        auth: {
          access_token: session.access_token,
          refresh_token: session.refresh_token,
          user_id: session.user?.id || auth.user_id || null,
        },
      };
      await setStore({ auth: next.auth });
      return next;
    }
    // refresh 也失败 → 清登录态，要求重新登录
    await setStore({ auth: null });
    return { cfg, auth: null, userEmail: store.userEmail };
  } catch {
    return store;
  }
}

// ===== 保证 user_id 存在 =====
// collect_items 的 RLS 要求写入行的 user_id = auth.uid()。
// 若本地登录态里恰好没有 user_id（旧版本数据、异常中断），入库会被 RLS 拦成 403，
// 用户只会看到「入库失败」却不知道原因。这里用当前 token 反查一次补齐。
async function ensureUserId(auth) {
  if (auth?.user_id) return auth;
  try {
    const resp = await fetch(`${CONFIG.url}/auth/v1/user`, {
      headers: { apikey: CONFIG.anonKey, Authorization: `Bearer ${auth.access_token}` },
    });
    if (resp.ok) {
      const u = await resp.json();
      if (u?.id) {
        const next = { ...auth, user_id: u.id };
        await setStore({ auth: next });
        return next;
      }
    }
  } catch {
    /* ignore */
  }
  return auth;
}

function show(el, text, cls) {
  el.textContent = text;
  el.className = `status ${cls}`;
}

// ===== 初始化视图 =====
document.addEventListener("DOMContentLoaded", async () => {
  const { auth, userEmail } = await getStore();
  if (!auth?.access_token) {
    $("setupView").style.display = "block";
  } else {
    $("mainView").style.display = "block";
    $("userEmail").textContent = userEmail || "";
  }
  // 密码框回车直接登录
  $("password").addEventListener("keydown", (e) => {
    if (e.key === "Enter") $("loginBtn").click();
  });
});

// ===== 登录（只需 ERP 账号密码，无需任何配置串）=====
$("loginBtn").addEventListener("click", async () => {
  const status = $("setupStatus");
  const cfg = CONFIG;
  const account = $("account").value.trim();
  const password = $("password").value;
  if (!account || !password) return show(status, "请输入账号和密码", "err");

  $("loginBtn").disabled = true;
  $("loginBtn").textContent = "登录中...";
  try {
    const session = await sbLogin(cfg, account, password);
    await setStore({
      cfg,
      auth: {
        access_token: session.access_token,
        refresh_token: session.refresh_token,
        user_id: session.user?.id || null,
      },
      userEmail: session.user?.email || session.user?.phone || account,
    });
    location.reload();
  } catch (e) {
    show(status, e.message, "err");
    $("loginBtn").disabled = false;
    $("loginBtn").textContent = "登录";
  }
});

$("registerLink").addEventListener("click", () => {
  chrome.tabs.create({ url: `${CONFIG.url}/register` });
});

// ===== 采集当前页 =====
async function doCollect() {
  const status = $("status");
  const preview = $("preview");
  const { cfg, auth } = await ensureFreshAuth();
  if (!cfg || !auth?.access_token) {
    location.reload(); // 登录态失效 → 回到配置页
    return;
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;

  $("collectBtn").disabled = true;
  $("collectBtn").textContent = "采集中...";
  show(status, "正在解析页面…", "ok");

  try {
    // 注入 content script（需 permissions.scripting）
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    const res = await chrome.tabs.sendMessage(tab.id, { type: "COLLECT_PAGE" });
    if (!res?.ok) throw new Error(res?.error || "页面解析失败");

    const item = res.data;
    // 预览
    preview.style.display = "block";
    preview.innerHTML = `
      ${item.image ? `<img src="${item.image}" onerror="this.style.display='none'">` : ""}
      <div class="name">${escapeHtml(item.name)}</div>
      <div class="meta">
        ${item.price ? `<span style="font-weight:700;color:#D95D2B">${item.currency === "CNY" ? "¥" : item.currency === "USD" ? "$" : ""}${Number(item.price).toFixed(2)}</span>` : ""}
        ${item.platform ? `<span class="tag">${escapeHtml(item.platform)}</span>` : ""}
        ${item.variants?.length ? `<span class="tag">${item.variants.length} 变体</span>` : ""}
        ${item.rating ? `<span class="tag">★ ${item.rating}</span>` : ""}
        ${item.images?.length ? `<span class="tag">${item.images.length} 图</span>` : ""}
      </div>`;

    show(status, "正在存入采集箱…", "ok");
    const authed = await ensureUserId(auth);
    await sbInsertCollect(cfg, authed.access_token, authed.user_id ?? null, item);
    show(status, "✓ 采集成功，已存入 ERP 采集箱", "ok");
  } catch (e) {
    show(status, `采集失败：${e.message}`, "err");
  } finally {
    $("collectBtn").disabled = false;
    $("collectBtn").textContent = "采集当前页面 (Alt+S)";
  }
}

// ===== 列表页整页采集 =====
// 并发 3 个后台标签页同时解析，支持随时停止；单条超时 15s 自动跳过，不拖垮整批。
let batchAbort = false;

async function waitTabLoaded(tabId, timeoutMs) {
  return new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      chrome.tabs.onUpdated.removeListener(listener);
      resolve();
    };
    const timer = setTimeout(finish, timeoutMs);
    function listener(id, info) {
      if (id === tabId && info.status === "complete") finish();
    }
    chrome.tabs.onUpdated.addListener(listener);
  });
}

async function collectOneLink(link, cfg, auth) {
  const subTab = await chrome.tabs.create({ url: link, active: false });
  try {
    await waitTabLoaded(subTab.id, 15000);
    await new Promise((r) => setTimeout(r, 1500)); // 等待动态渲染
    await chrome.scripting.executeScript({ target: { tabId: subTab.id }, files: ["content.js"] });
    const res = await chrome.tabs.sendMessage(subTab.id, { type: "COLLECT_PAGE" });
    if (!res?.ok) throw new Error(res?.error || "解析失败");
    if (!res.data?.name || res.data.name === "未命名商品") throw new Error("页面无有效商品信息");
    await sbInsertCollect(cfg, auth.access_token, auth.user_id ?? null, res.data);
    return true;
  } finally {
    chrome.tabs.remove(subTab.id).catch(() => {});
  }
}

async function doCollectAll() {
  const status = $("status");
  if (batchAbort) return; // 正在停止中

  const { cfg, auth } = await ensureFreshAuth();
  if (!auth?.access_token) {
    location.reload();
    return;
  }

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;

  $("collectAllBtn").disabled = true;
  $("preview").style.display = "none";
  batchAbort = false;

  try {
    await chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["content.js"] });
    const res = await chrome.tabs.sendMessage(tab.id, { type: "COLLECT_LISTING" });
    if (!res?.ok) throw new Error(res?.error || "页面解析失败");
    const links = (res.links || []).slice(0, 60);
    if (links.length === 0) {
      show(status, "本页未发现商品链接——请到搜索结果 / 店铺 / 类目列表页使用", "err");
      return;
    }

    $("collectAllBtn").textContent = `停止（0/${links.length}）`;
    $("collectAllBtn").disabled = false;

    // 并发窗口
    const authed = await ensureUserId(auth);
    const CONCURRENCY = 3;
    let idx = 0;
    let ok = 0;
    let fail = 0;
    const worker = async () => {
      while (idx < links.length && !batchAbort) {
        const i = idx++;
        show(status, `正在采集 ${Math.min(i + CONCURRENCY, links.length)}/${links.length} …`, "ok");
        try {
          await collectOneLink(links[i], cfg, authed);
          ok++;
        } catch {
          fail++;
        }
        $("collectAllBtn").textContent = `停止（${ok + fail}/${links.length}）`;
      }
    };
    await Promise.all(Array.from({ length: Math.min(CONCURRENCY, links.length) }, worker));

    if (batchAbort) {
      show(status, `已停止：本次成功 ${ok}，失败 ${fail}，未采集 ${links.length - ok - fail} 条`, "err");
    } else {
      show(status, `✓ 整页采集完成：成功 ${ok}，失败 ${fail}，已存入公用采集箱`, "ok");
    }
  } catch (e) {
    show(status, `采集失败：${e.message}`, "err");
  } finally {
    batchAbort = false;
    $("collectAllBtn").disabled = false;
    $("collectAllBtn").textContent = "采集本页全部商品";
  }
}

$("collectBtn").addEventListener("click", doCollect);
$("collectAllBtn").addEventListener("click", () => {
  // 采集中再次点击 = 停止
  if (!batchAbort && $("collectAllBtn").textContent.includes("停止")) {
    batchAbort = true;
    $("collectAllBtn").textContent = "正在停止…";
    return;
  }
  doCollectAll();
});
$("openBoxBtn").addEventListener("click", () => {
  chrome.tabs.create({ url: `${CONFIG.url}/products/collect` });
});

function escapeHtml(s) {
  return String(s || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]);
}
