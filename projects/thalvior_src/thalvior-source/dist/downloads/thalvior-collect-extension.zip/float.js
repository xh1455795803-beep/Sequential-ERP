// Thalvior 智能采集 —— 电商页悬浮按钮（v2.0）
// 商品页：采集此商品；列表/搜索页：采集本页商品链接（先入采集箱，再在 ERP 中逐条解析）
(function () {
  "use strict";
  if (window.__thalviorFloat) return;
  window.__thalviorFloat = true;

  const tip = document.createElement("div");
  tip.style.cssText =
    "position:fixed;right:18px;bottom:118px;z-index:2147483647;background:#111827;color:#fff;border-radius:10px;" +
    "padding:8px 12px;font:12px/1.5 system-ui,sans-serif;display:none;max-width:280px;box-shadow:0 8px 24px rgba(0,0,0,.3);";
  tip.textContent = "Thalvior 采集";

  const box = document.createElement("div");
  box.style.cssText =
    "position:fixed;right:18px;bottom:18px;z-index:2147483647;display:flex;flex-direction:column;gap:8px;" +
    "font-family:system-ui,-apple-system,sans-serif;";

  function mkBtn(text, bg) {
    const b = document.createElement("button");
    b.textContent = text;
    b.style.cssText =
      "background:" + bg + ";color:#fff;border:none;border-radius:999px;padding:10px 18px;font-size:14px;" +
      "font-weight:600;box-shadow:0 6px 20px rgba(0,0,0,.28);cursor:pointer;letter-spacing:.3px;";
    b.addEventListener("mouseenter", () => (b.style.filter = "brightness(1.12)"));
    b.addEventListener("mouseleave", () => (b.style.filter = ""));
    return b;
  }

  const btn = mkBtn("采集此商品 → Thalvior", "#0F4C5C");
  const listBtn = mkBtn("采集本页商品链接", "#1F7A4D");
  const closeBtn = document.createElement("span");
  closeBtn.textContent = "×";
  closeBtn.title = "收起 Thalvior 采集按钮";
  closeBtn.style.cssText =
    "position:absolute;top:-7px;right:-2px;width:18px;height:18px;border-radius:50%;background:#374151;color:#fff;" +
    "font:12px/18px system-ui;text-align:center;cursor:pointer;display:none;";

  box.style.position = "fixed";
  box.appendChild(closeBtn);
  box.appendChild(btn);
  box.appendChild(listBtn);
  document.documentElement.appendChild(box);
  document.documentElement.appendChild(tip);

  function flash(msg, ok) {
    tip.style.display = "block";
    tip.style.background = ok ? "#0F4C5C" : "#7F1D1D";
    tip.textContent = msg;
    clearTimeout(flash._t);
    // 错误引导文案较长（含"完成验证后重试"步骤），按长度延长展示时间便于阅读
    const ms = ok ? 3200 : Math.max(3200, Math.min(9000, String(msg).length * 220));
    flash._t = setTimeout(() => (tip.style.display = "none"), ms);
  }

  function run(type, el, doneText) {
    const old = el.textContent;
    el.textContent = "采集中…";
    el.disabled = true;
    el.style.opacity = ".7";
    try {
      chrome.runtime.sendMessage({ type: type }, (res) => {
        el.disabled = false;
        el.style.opacity = "";
        const err = chrome.runtime.lastError;
        if (err) {
          el.textContent = old;
          flash("插件异常，请刷新页面重试", false);
          return;
        }
        if (res && res.ok) {
          el.textContent = "✓ " + doneText;
          flash(res.msg || "已存入 Thalvior 公用采集箱，可回 ERP 认领", true);
          setTimeout(() => (el.textContent = old), 2400);
        } else {
          el.textContent = old;
          flash((res && res.error) || "采集失败，请稍后重试", false);
        }
      });
    } catch (e) {
      el.disabled = false;
      el.style.opacity = "";
      el.textContent = old;
    }
  }

  btn.addEventListener("click", () => run("FLOAT_COLLECT", btn, "已入采集箱"));
  listBtn.addEventListener("click", () => run("FLOAT_COLLECT_LIST", listBtn, "已提交到采集箱"));

  // 智能显示：非商品详情页隐藏"采集此商品"，无商品链接列表隐藏"采集本页"
  let probed = false;
  setTimeout(() => {
    if (probed) return;
    probed = true;
    try {
      chrome.runtime.sendMessage({ type: "FLOAT_PROBE" }, (res) => {
        if (chrome.runtime.lastError || !res || !res.ok) return;
        if (res.isList && !res.isProductPage) btn.style.display = "none";
        if (res.isProductPage && !res.isList) listBtn.style.display = "none";
      });
    } catch (e) {}
  }, 1200);

  // 收起后可从角落小图标唤回
  closeBtn.addEventListener("click", () => {
    box.style.display = "none";
    const mini = document.createElement("div");
    mini.textContent = "采";
    mini.title = "展开 Thalvior 采集";
    mini.style.cssText =
      "position:fixed;right:18px;bottom:18px;z-index:2147483647;width:34px;height:34px;border-radius:50%;" +
      "background:#0F4C5C;color:#fff;font:14px/34px system-ui;text-align:center;cursor:pointer;" +
      "box-shadow:0 4px 14px rgba(0,0,0,.3);opacity:.85;";
    mini.addEventListener("click", () => {
      box.style.display = "flex";
      mini.remove();
    });
    document.documentElement.appendChild(mini);
  });
})();
