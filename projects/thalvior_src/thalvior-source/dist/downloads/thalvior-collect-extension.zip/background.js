// Thalvior 智能采集插件 —— background service worker（v2.0）
// 采集路径：① Alt+S 快捷键 ② popup 按钮 ③ 电商页悬浮按钮（FLOAT_COLLECT）
//           ④ 列表页采集本页链接（FLOAT_COLLECT_LIST，先入采集箱，ERP 中解析）
"use strict";

const CONFIG = {
  url: "https://thalvior.icu",
  anonKey:
    "eyJhbGciOiAiSFMyNTYiLCAidHlwIjogIkpXVCJ9.eyJyb2xlIjogImFub24iLCAiaXNzIjogInN1cGFiYXNlIiwgImlhdCI6IDE3OTAyNjgwMTYsICJleHAiOiAyMTA1NjI4MDE2fQ.P3s0YUizo985KezDkYZLOSbJGB0_2EaEzLd23MGSsFw",
  appId: "pm45exfrqoja",
};

async function ensureFreshAuth() {
  const store = await chrome.storage.local.get(["auth"]);
  const cfg = CONFIG;
  const { auth } = store;
  if (!auth?.access_token) return { cfg, auth: null };
  try {
    const payload = JSON.parse(atob(auth.access_token.split(".")[1].replace(/-/g, "+").replace(/_/g, "/")));
    const expiresAt = (payload.exp || 0) * 1000;
    if (expiresAt - Date.now() > 2 * 60 * 1000) return { cfg, auth };
    const resp = await fetch(`${cfg.url}/auth/v1/token?grant_type=refresh_token`, {
      method: "POST",
      headers: { "Content-Type": "application/json", apikey: cfg.anonKey },
      body: JSON.stringify({ refresh_token: auth.refresh_token }),
    });
    if (resp.ok) {
      const session = await resp.json();
      const nextAuth = {
        access_token: session.access_token,
        refresh_token: session.refresh_token,
        user_id: session.user?.id || auth.user_id || null,
      };
      await chrome.storage.local.set({ auth: nextAuth });
      return { cfg, auth: nextAuth };
    }
    await chrome.storage.local.set({ auth: null });
    return { cfg, auth: null };
  } catch {
    return { cfg, auth };
  }
}

async function getActiveTab() {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  return tab && tab.id ? tab : null;
}

async function ensureContent(tabId) {
  try {
    const r = await chrome.tabs.sendMessage(tabId, { type: "COLLECT_PAGE" });
    if (r && typeof r.ok === "boolean") return;
  } catch (e) {
    /* not injected yet */
  }
  await chrome.scripting.executeScript({ target: { tabId }, files: ["content.js"] });
}

function platformFromUrl(u) {
  try {
    const h = new URL(u).hostname;
    if (/1688\.com$/.test(h)) return "1688";
    if (/taobao\.com$/.test(h)) return "淘宝";
    if (/tmall\.com$/.test(h)) return "天猫";
    if (/amazon\./.test(h)) return "Amazon";
    if (/aliexpress\./.test(h)) return "AliExpress";
    if (/ebay\./.test(h)) return "eBay";
    if (/temu\.com$/.test(h)) return "Temu";
    if (/shein\./.test(h)) return "SHEIN";
    if (/tiktok\.com$/.test(h)) return "TikTok";
    if (/(^|\.)jd\.com$/.test(h)) return "京东";
    if (/yangkeduo\.com$/.test(h)) return "拼多多";
    if (/lazada\./.test(h)) return "Lazada";
    if (/shopee\./.test(h)) return "Shopee";
    if (/walmart\.com$/.test(h)) return "Walmart";
    if (/etsy\.com$/.test(h)) return "Etsy";
    if (/alibaba\.com$/.test(h)) return "Alibaba";
    if (/dhgate\.com$/.test(h)) return "敦煌网";
    if (/made-in-china\.com$/.test(h)) return "中国制造";
    if (/wish\.com$/.test(h)) return "Wish";
    if (/ozon\.ru$/.test(h)) return "Ozon";
    if (/wildberries\.ru$/.test(h)) return "Wildberries";
    return "Web";
    return h.replace(/^www\./, "") || "Web";
  } catch {
    return "Web";
  }
}

function shortName(u) {
  try {
    const url = new URL(u);
    const seg = url.pathname.split("/").filter(Boolean).pop() || url.hostname;
    return `待解析 · ${platformFromUrl(u)} · ${String(seg).slice(0, 24)}`;
  } catch {
    return `待解析 · ${u.slice(0, 40)}`;
  }
}

function badge(text, color) {
  chrome.action.setBadgeText({ text });
  chrome.action.setBadgeBackgroundColor({ color });
  setTimeout(() => chrome.action.setBadgeText({ text: "" }), 1500);
}

async function insertItems(auth, items) {
  const resp = await fetch(`${CONFIG.url}/rest/v1/collect_items`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      apikey: CONFIG.anonKey,
      Authorization: `Bearer ${auth.access_token}`,
      Prefer: "return=minimal",
    },
    body: JSON.stringify(items),
  });
  if (!resp.ok) throw new Error(`入库失败 (${resp.status})`);
}

// 采集当前页商品 → 公用采集箱
async function collectAndSave() {
  try {
    const { cfg, auth } = await ensureFreshAuth();
    if (!cfg || !auth?.access_token) {
      return { ok: false, error: "请先在插件弹窗中登录 Thalvior 账号" };
    }
    const tab = await getActiveTab();
    if (!tab) return { ok: false, error: "未找到活动标签页" };

    let authed = auth;
    if (!authed.user_id) {
      try {
        const me = await fetch(`${cfg.url}/auth/v1/user`, {
          headers: { apikey: cfg.anonKey, Authorization: `Bearer ${auth.access_token}` },
        });
        if (me.ok) {
          const u = await me.json();
          if (u?.id) {
            authed = { ...auth, user_id: u.id };
            await chrome.storage.local.set({ auth: authed });
          }
        }
      } catch (e) {
        /* ignore */
      }
    }
    await ensureContent(tab.id);
    const res = await chrome.tabs.sendMessage(tab.id, { type: "COLLECT_PAGE" });
    if (!res?.ok) return { ok: false, error: res?.error || "页面解析失败" };
    const item = res.data;
    if (!item?.name || item.name === "未命名商品") {
      let u = "";
      try { u = new URL(tab.url || "").hostname; } catch (_) { /* ignore */ }
      const isCnySource = /1688\.com|taobao\.com|tmall\.com/i.test(u);
      return {
        ok: false,
        error: isCnySource
          ? "未能识别商品信息：1688/淘宝需先登录并完成滑块验证、页面完全加载后再点采集（请滚动页面确认已显示正常商品内容）"
          : "未能识别商品信息：请确认这是商品详情页，并等页面完全加载后再点采集",
      };
    }
    await insertItems(authed, [
      {
        name: item.name,
        source: item.source || tab.url,
        category: "插件采集",
        price: item.price || null,
        original_price: item.originalPrice || null,
        currency: item.currency || null,
        image: item.image || null,
        images: item.images || [],
        detail_images: item.detailImages || [],
        description: item.description || null,
        sku: item.sku || null,
        brand: item.brand || null,
        seller: item.seller || null,
        rating: item.rating || null,
        reviews: item.reviews || null,
        sales: item.sales || null,
        variants: item.variants || [],
        platform: item.platform || platformFromUrl(tab.url),
        status: "待处理",
        user_id: authed.user_id || null,
      },
    ]);
    badge("✓", "#1F7A4D");
    return { ok: true, name: item.name, msg: "已存入 Thalvior 公用采集箱，可回 ERP 认领转产品" };
  } catch (e) {
    badge("!", "#B3382C");
    return { ok: false, error: String(e?.message || e) };
  }
}

// 探测页面类型（商品页 / 列表页）与可采集列表
async function probePage() {
  try {
    const tab = await getActiveTab();
    if (!tab) return { ok: false };
    await ensureContent(tab.id);
    const res = await chrome.tabs.sendMessage(tab.id, { type: "COLLECT_LISTING" });
    if (!res?.ok) return { ok: false };
    return { ok: true, isList: (res.links || []).length > 2, isProductPage: !!res.isProductPage };
  } catch (e) {
    return { ok: false };
  }
}

// 列表页：把本页商品链接批量提交到采集箱（待解析）
async function collectListingLinks() {
  try {
    const { cfg, auth } = await ensureFreshAuth();
    if (!cfg || !auth?.access_token) {
      return { ok: false, error: "请先在插件弹窗中登录 Thalvior 账号" };
    }
    const tab = await getActiveTab();
    if (!tab) return { ok: false, error: "未找到活动标签页" };
    let authed = auth;
    if (!authed.user_id) {
      try {
        const me = await fetch(`${cfg.url}/auth/v1/user`, {
          headers: { apikey: cfg.anonKey, Authorization: `Bearer ${auth.access_token}` },
        });
        if (me.ok) {
          const u = await me.json();
          if (u?.id) authed = { ...auth, user_id: u.id };
        }
      } catch (e) {
        /* ignore */
      }
    }
    await ensureContent(tab.id);
    const res = await chrome.tabs.sendMessage(tab.id, { type: "COLLECT_LISTING" });
    if (!res?.ok) return { ok: false, error: res?.error || "本页未发现商品链接" };
    const links = (res.links || []).slice(0, 60);
    if (links.length === 0) return { ok: false, error: "本页未发现商品链接" };
    const items = links.map((u) => ({
      name: shortName(u),
      source: u,
      category: "列表采集",
      platform: platformFromUrl(u),
      status: "待处理",
      user_id: authed.user_id || null,
    }));
    await insertItems(authed, items);
    badge("✓", "#1F7A4D");
    return { ok: true, msg: `已提交 ${links.length} 条商品链接，回 ERP 采集箱点「解析」抓取详情` };
  } catch (e) {
    badge("!", "#B3382C");
    return { ok: false, error: String(e?.message || e) };
  }
}

chrome.commands.onCommand.addListener((command) => {
  if (command === "collect-current-page") collectAndSave();
});

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  if (msg?.type === "FLOAT_COLLECT") {
    collectAndSave().then(sendResponse);
    return true;
  }
  if (msg?.type === "FLOAT_COLLECT_LIST") {
    collectListingLinks().then(sendResponse);
    return true;
  }
  if (msg?.type === "FLOAT_PROBE") {
    probePage().then(sendResponse);
    return true;
  }
});

// ─── 外部连接：ERP 页面探测插件真实状态（externally_connectable 仅限 thalvior.icu） ───
chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === "PING") {
    chrome.storage.local.get(["auth"]).then(({ auth }) => {
      sendResponse({
        pong: true,
        version: chrome.runtime.getManifest().version,
        loggedIn: !!(auth && auth.access_token),
      });
    });
    return true;
  }
});
