#!/usr/bin/env node
/** 精确测量：表格密度/列宽/容器底色/元素计数（只读） */
const { chromium } = require('/opt/thalvior-source/node_modules/playwright-core');
const fs = require('fs');
const env = fs.readFileSync('/opt/thalvior-source/.env', 'utf8');
const sbUrl = (env.match(/^VITE_SUPABASE_URL=(.+)$/m) || [])[1].trim().replace(/"/g, '');

const PAGES = [
  ['/orders', 'orders'],
  ['/products', 'products'],
  ['/finance/profit', 'profit'],
  ['/automation', 'automation'],
];

(async () => {
  const b = await chromium.launch({ args: ['--no-sandbox'] });
  const sess = await fetch(sbUrl + '/auth/v1/token?grant_type=password', {
    method: 'POST',
    headers: { apikey: (env.match(/^VITE_SUPABASE_ANON_KEY=(.+)$/m) || [])[1].trim().replace(/"/g, ''), 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'qa.vis@visaudit.test', password: 'VisAudit#2025x' }),
  }).then(r => r.json());
  const ctx = await b.newContext({ viewport: { width: 1440, height: 900 } });
  await ctx.addInitScript((s) => {
    localStorage.setItem('sb-thalvior-auth-token', s.raw);
    localStorage.setItem('thalvior_lang', 'zh');
    localStorage.setItem('thalvior_theme', 'light');
  }, { raw: JSON.stringify({ access_token: sess.access_token, refresh_token: sess.refresh_token, user: sess.user, expires_at: Math.floor(Date.now()/1000) + 3600 }) });
  const p = await ctx.newPage();

  for (const [path, key] of PAGES) {
    await p.goto('https://thalvior.icu' + path, { waitUntil: 'domcontentloaded' });
    await p.waitForTimeout(3500);
    const out = await p.evaluate(() => {
      const g = (el, ps) => { if (!el) return null; const c = getComputedStyle(el); const o = {}; ps.forEach(k => o[k] = c.getPropertyValue(k)); return o; };
      const r = {};
      const tbl = document.querySelector('table');
      if (tbl) {
        const ths = [...tbl.querySelectorAll('thead th')];
        r.theadCols = ths.map(th => ({ text: (th.innerText || '').trim().slice(0, 14), w: Math.round(th.getBoundingClientRect().width), fs: getComputedStyle(th).fontSize, fw: getComputedStyle(th).fontWeight, color: getComputedStyle(th).color, bg: getComputedStyle(th).backgroundColor, pad: getComputedStyle(th).paddingLeft }));
        const rows = [...tbl.querySelectorAll('tbody tr')];
        r.rowCount = rows.length;
        r.rowHeights = rows.slice(0, 5).map(tr => Math.round(tr.getBoundingClientRect().height));
        r.tbodyBg = getComputedStyle(tbl.querySelector('tbody')).backgroundColor;
        r.striped = rows.some((tr, i) => i > 0 && getComputedStyle(tr).backgroundColor !== getComputedStyle(rows[0]).backgroundColor);
        const tds = [...(tbl.querySelector('tbody tr')?.querySelectorAll('td') || [])];
        r.tdSample = tds.slice(0, 6).map(td => ({ text: (td.innerText || '').trim().slice(0, 12), w: Math.round(td.getBoundingClientRect().width), fs: getComputedStyle(td).fontSize, pad: getComputedStyle(td).paddingLeft, color: getComputedStyle(td).color, nowrap: getComputedStyle(td).whiteSpace }));
        r.tblBorder = getComputedStyle(tbl).borderBottomWidth + ' ' + getComputedStyle(tbl.querySelector('thead th')).borderBottomWidth;
        r.tblFont = getComputedStyle(tbl).fontSize;
        // 表头 sticky?
        r.thPosition = getComputedStyle(tbl.querySelector('thead th')).position;
        r.thBg = getComputedStyle(tbl.querySelector('thead th')).backgroundColor;
      } else { r.noTable = true; }
      // 页面容器底色链
      const chain = [];
      let el = document.querySelector('main') || document.body;
      while (el && chain.length < 6) {
        chain.push({ tag: el.tagName, cls: (el.className || '').toString().slice(0, 60), bg: getComputedStyle(el).backgroundColor, pad: getComputedStyle(el).paddingLeft + '/' + getComputedStyle(el).paddingTop });
        el = el.parentElement;
      }
      r.containerChain = chain;
      r.bodyBg = getComputedStyle(document.body).backgroundColor;
      r.bodyColor = getComputedStyle(document.body).color;
      r.bodyFont = getComputedStyle(document.body).fontFamily;
      r.bodyFontSize = getComputedStyle(document.body).fontSize;
      r.bodyLineHeight = getComputedStyle(document.body).lineHeight;
      // 全页面 distinct 颜色（背景+文字+边框）
      const bgSet = new Set(), txSet = new Set(), bdSet = new Set();
      document.querySelectorAll('*').forEach(el => {
        const c = getComputedStyle(el);
        if (el.getBoundingClientRect().height > 0) bgSet.add(c.backgroundColor);
        if ((el.textContent || '').trim()) txSet.add(c.color);
        if (c.borderTopWidth !== '0px') bdSet.add(c.borderTopColor);
      });
      r.distinctBg = [...bgSet];
      r.distinctText = [...txSet];
      r.distinctBorder = [...bdSet];
      // 按钮
      const btns = [...document.querySelectorAll('button')].slice(0, 6).map(bt => g(bt, ['height', 'border-radius', 'font-size', 'font-weight', 'background-color', 'color', 'padding-left', 'border-top-width', 'border-top-color', 'box-shadow']));
      r.buttons = btns;
      // 卡片圆角/阴影样本
      const cards = [...document.querySelectorAll('div')].filter(d => { const c = getComputedStyle(d); return c.boxShadow !== 'none' && d.getBoundingClientRect().width > 200; }).slice(0, 5);
      r.cards = cards.map(c => g(c, ['background-color', 'border-radius', 'box-shadow', 'border-top-width', 'border-top-color']));
      // 图标
      r.svgIcons = document.querySelectorAll('svg').length;
      r.lucideIcons = document.querySelectorAll('svg.lucide, svg[class*="lucide"]').length;
      // 徽标
      const bgs = [...document.querySelectorAll('span')].filter(s => /rounded-full/.test(s.className) && s.innerText.trim()).slice(0, 6);
      r.badges = bgs.map(s => g(s, ['font-size', 'background-color', 'color', 'padding-left', 'padding-top', 'border-radius', 'border-top-width', 'border-top-color', 'height']));
      return r;
    });
    console.log('\n########## ' + key + ' (' + path + ') ##########');
    console.log(JSON.stringify(out, null, 1));
  }
  await b.close();
})();
