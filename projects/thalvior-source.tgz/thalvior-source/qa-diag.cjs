const { chromium } = require('playwright-core');
(async () => {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage({ viewport: { width: 1440, height: 900 } });
  page.on('response', r => { if (r.status() >= 400) console.log('HTTP' + r.status() + ' ' + r.url().slice(0, 120)); });
  page.on('pageerror', e => console.log('PAGEERROR: ' + e.message.slice(0, 200)));
  await page.goto('https://thalvior.icu/login', { waitUntil: 'networkidle', timeout: 60000 });
  await page.locator('input:not([type="password"])').first().fill('qa-agent-test@thalvior.icu');
  await page.locator('input[type="password"]').first().fill('Qa#Test2026x');
  await page.locator('button', { hasText: /^登录$/ }).click();
  await page.waitForTimeout(4500);
  await page.goto('https://thalvior.icu/subscription', { waitUntil: 'networkidle', timeout: 60000 });
  await page.waitForTimeout(3000);
  const diag = await page.evaluate(() => ({
    url: location.href,
    title: document.title,
    rootChildren: document.getElementById('root') ? document.getElementById('root').children.length : -1,
    sections: Array.from(document.querySelectorAll('section')).map(s => s.id || '(noid)').slice(0, 10),
    scripts: Array.from(document.querySelectorAll('script[src]')).map(s => s.src.split('/').pop()),
    bodyText0: (document.body.innerText || '').slice(0, 120).replace(/\n/g, '|'),
    hasShopLicenseText: (document.body.innerText || '').includes('店铺授权额度'),
  }));
  console.log(JSON.stringify(diag, null, 1));
  await browser.close();
})();
