const { chromium } = require('playwright-core');
(async () => {
  const browser = await chromium.launch({ args: ['--no-sandbox', '--disable-dev-shm-usage'] });
  const page = await browser.newPage({ viewport: { width: 1440, height: 1000 } });
  try {
    await page.goto('https://thalvior.icu/login', { waitUntil: 'networkidle', timeout: 60000 });
    await page.locator('input:not([type="password"])').first().fill('qa-agent-test@thalvior.icu');
    await page.locator('input[type="password"]').first().fill('Qa#Test2026x');
    await page.locator('button', { hasText: /^登录$/ }).click();
    await page.waitForTimeout(4000);
    await page.goto('https://thalvior.icu/products/PRD-0001', { waitUntil: 'networkidle', timeout: 60000 });
    await page.waitForTimeout(2000);
    const card = page.locator('img[alt="img-0"]').first();
    await card.scrollIntoViewIfNeeded();
    await card.hover();
    await page.getByRole('button', { name: '恢复原图', exact: true }).first().click();
    await page.waitForTimeout(2500);
    const src = await card.getAttribute('src');
    console.log('RESTORED_URL=' + src);
    if (!src || !src.includes('prod-thermos.jpg')) throw new Error('restore failed');
    await page.screenshot({ path: '/tmp/prod_mt_restored.png' });
    console.log('RESTORE OK');
  } catch (e) {
    console.error('RESTORE FAIL: ' + e.message);
    process.exitCode = 1;
  } finally { await browser.close(); }
})();
